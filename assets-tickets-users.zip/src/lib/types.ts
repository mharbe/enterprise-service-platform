export interface Department {
  id: string;
  name: string;
  email: string;
  description: string;
  color: string;
  created_at: string;
}

export interface ManagedUser {
  id: string;
  first_name: string;
  last_name: string;
  full_name: string;
  email: string;
  town: string;
  state: string;
  building: string;
  room: string;
  department_id: string;
  supervisor_id: string | null;
  manager_id: string | null;
  role: string;
  status: string;
  avatar_url: string | null;
  phone: string;
  title: string;
  source: string;
  created_at: string;
  updated_at: string;
  department?: Department;
  supervisor?: ManagedUser;
}

export type AssetStatus = 'in_use' | 'assigned' | 'available' | 'in_stock' | 'lost' | 'stolen' | 'unavailable';

export interface Asset {
  id: string;
  asset_tag: string;
  name: string;
  category: string;
  make: string;
  model: string;
  serial_number: string;
  status: AssetStatus;
  status_note: string | null;
  assigned_user_id: string | null;
  department_id: string;
  building: string;
  room: string;
  purchase_date: string;
  purchase_cost: number;
  warranty_expiry: string;
  condition: string;
  notes: string | null;
  created_at: string;
  updated_at: string;
  assigned_user?: ManagedUser;
  department?: Department;
}

export type TicketStatus = 'open' | 'in_progress' | 'pending' | 'resolved' | 'closed';
export type TicketPriority = 'low' | 'medium' | 'high' | 'critical';

export interface Ticket {
  id: string;
  ticket_number: string;
  subject: string;
  description: string;
  status: TicketStatus;
  priority: TicketPriority;
  category: string;
  subcategory: string;
  department_id: string;
  requester_id: string | null;
  requester_name: string;
  requester_email: string;
  assigned_to: string | null;
  asset_id: string | null;
  source: string;
  resolution: string | null;
  ai_suggestion: string | null;
  tags: string[];
  attachments: string[];
  created_at: string;
  updated_at: string;
  resolved_at: string | null;
  closed_at: string | null;
  department?: Department;
  assigned_user?: ManagedUser;
  asset?: Asset;
}

export interface TicketComment {
  id: string;
  ticket_id: string;
  author_id: string | null;
  author_name: string;
  content: string;
  is_internal: boolean;
  is_ai: boolean;
  created_at: string;
}

export interface AssetHistory {
  id: string;
  asset_id: string;
  action: string;
  details: string;
  performed_by: string | null;
  ticket_id: string | null;
  old_status: string | null;
  new_status: string | null;
  created_at: string;
}

export interface KBArticle {
  id: string;
  title: string;
  content: string;
  category: string;
  tags: string[];
  department_id: string;
  author_id: string | null;
  status: string;
  views: number;
  helpful_count: number;
  created_at: string;
  updated_at: string;
  department?: Department;
}

export interface CustomRole {
  id: string;
  name: string;
  description: string;
  permissions: Record<string, Record<string, boolean>>;
  department_id: string | null;
  created_at: string;
}

export interface Integration {
  id: string;
  name: string;
  type: string;
  config: Record<string, any>;
  status: string;
  last_sync: string | null;
  department_id: string | null;
  created_at: string;
}

export type ViewType = 'dashboard' | 'assets' | 'asset-detail' | 'tickets' | 'ticket-detail' | 'ticket-create' | 'users' | 'user-detail' | 'kb' | 'kb-article' | 'integrations' | 'settings' | 'submit-ticket';
