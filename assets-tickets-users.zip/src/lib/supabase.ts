import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://bvwgfwkqwcwkqayyytkf.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6ImQzNDZhOTA3LWEyYjUtNDkwOC04MzgxLTdmOTNiZTNkZDhhYyJ9.eyJwcm9qZWN0SWQiOiJidndnZndrcXdjd2txYXl5eXRrZiIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzc1MjM5MDU2LCJleHAiOjIwOTA1OTkwNTYsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.Vz_S6efQaa5TH7aUGrIReeDI14PHj9og3toeP1NUW-o';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };