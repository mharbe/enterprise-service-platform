import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import type { Department, ManagedUser, Asset, Ticket, KBArticle, CustomRole, Integration, ViewType, AssetStatus, TicketStatus, TicketPriority } from '@/lib/types';

interface AppContextType {
  sidebarOpen: boolean;
  toggleSidebar: () => void;
  currentView: ViewType;
  setCurrentView: (view: ViewType) => void;
  selectedId: string | null;
  setSelectedId: (id: string | null) => void;
  departments: Department[];
  users: ManagedUser[];
  assets: Asset[];
  tickets: Ticket[];
  kbArticles: KBArticle[];
  roles: CustomRole[];
  integrations: Integration[];
  loading: boolean;
  refreshData: () => Promise<void>;
  createTicket: (ticket: Partial<Ticket>) => Promise<Ticket | null>;
  updateTicket: (id: string, updates: Partial<Ticket>) => Promise<void>;
  createAsset: (asset: Partial<Asset>) => Promise<Asset | null>;
  updateAsset: (id: string, updates: Partial<Asset>) => Promise<void>;
  createUser: (user: Partial<ManagedUser>) => Promise<ManagedUser | null>;
  updateUser: (id: string, updates: Partial<ManagedUser>) => Promise<void>;
  createKBArticle: (article: Partial<KBArticle>) => Promise<KBArticle | null>;
  createRole: (role: Partial<CustomRole>) => Promise<void>;
  updateRole: (id: string, updates: Partial<CustomRole>) => Promise<void>;
  deleteRole: (id: string) => Promise<void>;
  navigateTo: (view: ViewType, id?: string) => void;
}

const AppContext = createContext<AppContextType>({} as AppContextType);

export const useAppContext = () => useContext(AppContext);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [currentView, setCurrentView] = useState<ViewType>('dashboard');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [users, setUsers] = useState<ManagedUser[]>([]);
  const [assets, setAssets] = useState<Asset[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [kbArticles, setKbArticles] = useState<KBArticle[]>([]);
  const [roles, setRoles] = useState<CustomRole[]>([]);
  const [integrations, setIntegrations] = useState<Integration[]>([]);
  const [loading, setLoading] = useState(true);

  const toggleSidebar = () => setSidebarOpen(prev => !prev);

  const navigateTo = useCallback((view: ViewType, id?: string) => {
    setCurrentView(view);
    if (id) setSelectedId(id);
    else setSelectedId(null);
  }, []);

  const refreshData = useCallback(async () => {
    setLoading(true);
    try {
      const [deptRes, userRes, assetRes, ticketRes, kbRes, roleRes, intRes] = await Promise.all([
        supabase.from('departments').select('*').order('name'),
        supabase.from('managed_users').select('*').order('last_name'),
        supabase.from('assets').select('*').order('asset_tag'),
        supabase.from('tickets').select('*').order('created_at', { ascending: false }),
        supabase.from('kb_articles').select('*').order('views', { ascending: false }),
        supabase.from('custom_roles').select('*').order('name'),
        supabase.from('integrations').select('*').order('name'),
      ]);

      if (deptRes.data) setDepartments(deptRes.data);
      if (userRes.data) setUsers(userRes.data);
      if (assetRes.data) setAssets(assetRes.data);
      if (ticketRes.data) setTickets(ticketRes.data);
      if (kbRes.data) setKbArticles(kbRes.data);
      if (roleRes.data) setRoles(roleRes.data);
      if (intRes.data) setIntegrations(intRes.data);
    } catch (err) {
      console.error('Error loading data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  const createTicket = async (ticket: Partial<Ticket>) => {
    const ticketNumber = `TKT-${new Date().getFullYear()}-${String(tickets.length + 13).padStart(3, '0')}`;
    const { data, error } = await supabase.from('tickets').insert({ ...ticket, ticket_number: ticketNumber }).select().single();
    if (error) { toast.error('Failed to create ticket'); return null; }
    toast.success('Ticket created successfully');
    await refreshData();
    return data;
  };

  const updateTicket = async (id: string, updates: Partial<Ticket>) => {
    const { error } = await supabase.from('tickets').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) { toast.error('Failed to update ticket'); return; }
    toast.success('Ticket updated');
    await refreshData();
  };

  const createAsset = async (asset: Partial<Asset>) => {
    const { data, error } = await supabase.from('assets').insert(asset).select().single();
    if (error) { toast.error('Failed to create asset'); return null; }
    toast.success('Asset created successfully');
    await refreshData();
    return data;
  };

  const updateAsset = async (id: string, updates: Partial<Asset>) => {
    const { error } = await supabase.from('assets').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) { toast.error('Failed to update asset'); return; }
    toast.success('Asset updated');
    await refreshData();
  };

  const createUser = async (user: Partial<ManagedUser>) => {
    const { data, error } = await supabase.from('managed_users').insert(user).select().single();
    if (error) { toast.error('Failed to create user'); return null; }
    toast.success('User created successfully');
    await refreshData();
    return data;
  };

  const updateUser = async (id: string, updates: Partial<ManagedUser>) => {
    const { error } = await supabase.from('managed_users').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id);
    if (error) { toast.error('Failed to update user'); return; }
    toast.success('User updated');
    await refreshData();
  };

  const createKBArticle = async (article: Partial<KBArticle>) => {
    const { data, error } = await supabase.from('kb_articles').insert(article).select().single();
    if (error) { toast.error('Failed to create article'); return null; }
    toast.success('KB Article created');
    await refreshData();
    return data;
  };

  const createRole = async (role: Partial<CustomRole>) => {
    const { error } = await supabase.from('custom_roles').insert(role);
    if (error) { toast.error('Failed to create role'); return; }
    toast.success('Role created');
    await refreshData();
  };

  const updateRole = async (id: string, updates: Partial<CustomRole>) => {
    const { error } = await supabase.from('custom_roles').update(updates).eq('id', id);
    if (error) { toast.error('Failed to update role'); return; }
    toast.success('Role updated');
    await refreshData();
  };

  const deleteRole = async (id: string) => {
    const { error } = await supabase.from('custom_roles').delete().eq('id', id);
    if (error) { toast.error('Failed to delete role'); return; }
    toast.success('Role deleted');
    await refreshData();
  };

  return (
    <AppContext.Provider value={{
      sidebarOpen, toggleSidebar, currentView, setCurrentView, selectedId, setSelectedId,
      departments, users, assets, tickets, kbArticles, roles, integrations, loading, refreshData,
      createTicket, updateTicket, createAsset, updateAsset, createUser, updateUser,
      createKBArticle, createRole, updateRole, deleteRole, navigateTo,
    }}>
      {children}
    </AppContext.Provider>
  );
};
