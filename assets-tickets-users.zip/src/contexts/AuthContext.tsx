import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Session, User } from '@supabase/supabase-js';
import type { ManagedUser, CustomRole } from '@/lib/types';

interface AuthContextType {
  session: Session | null;
  user: User | null;
  managedUser: ManagedUser | null;
  userRole: CustomRole | null;
  loading: boolean;
  signUp: (email: string, password: string, firstName: string, lastName: string) => Promise<string | null>;
  signIn: (email: string, password: string) => Promise<string | null>;
  signOut: () => Promise<void>;
  can: (module: string, action: string) => boolean;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);
export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [managedUser, setManagedUser] = useState<ManagedUser | null>(null);
  const [userRole, setUserRole] = useState<CustomRole | null>(null);
  const [loading, setLoading] = useState(true);

  const fetchManagedUser = useCallback(async (email: string) => {
    const { data: mu } = await supabase
      .from('managed_users')
      .select('*')
      .eq('email', email)
      .maybeSingle();
    setManagedUser(mu);

    if (mu?.role) {
      // Map the simple role string to a custom_roles record
      const roleNameMap: Record<string, string> = {
        admin: 'Super Admin',
        manager: 'IT Manager',
        technician: 'Technician',
        user: 'End User',
      };
      const roleName = roleNameMap[mu.role] || 'End User';
      const { data: role } = await supabase
        .from('custom_roles')
        .select('*')
        .eq('name', roleName)
        .maybeSingle();
      setUserRole(role);
    }
    return mu;
  }, []);

  // Listen for auth state changes and restore session
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user?.email) {
        fetchManagedUser(s.user.email).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, s) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user?.email) {
        fetchManagedUser(s.user.email);
      } else {
        setManagedUser(null);
        setUserRole(null);
      }
    });

    return () => subscription.unsubscribe();
  }, [fetchManagedUser]);

  const signUp = async (email: string, password: string, firstName: string, lastName: string): Promise<string | null> => {
    const { data, error } = await supabase.auth.signUp({ email, password });
    if (error) return error.message;

    // Create a managed_users record linked to this auth user
    const { error: muError } = await supabase.from('managed_users').insert({
      first_name: firstName,
      last_name: lastName,
      email,
      role: 'user',
      status: 'active',
      source: 'self-registration',
    });
    if (muError && !muError.message.includes('duplicate')) {
      console.error('Failed to create managed user:', muError);
    }

    // Fetch the managed user right away
    if (data.user?.email) await fetchManagedUser(data.user.email);
    return null;
  };

  const signIn = async (email: string, password: string): Promise<string | null> => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) return error.message;
    return null;
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setManagedUser(null);
    setUserRole(null);
  };

  const can = useCallback((module: string, action: string): boolean => {
    // If not authenticated, only allow viewing public content
    if (!managedUser) return false;
    // Super admins can do everything
    if (managedUser.role === 'admin') return true;
    // Check role permissions
    if (!userRole?.permissions) return false;
    return userRole.permissions[module]?.[action] === true;
  }, [managedUser, userRole]);

  return (
    <AuthContext.Provider value={{
      session, user, managedUser, userRole, loading,
      signUp, signIn, signOut, can,
      isAuthenticated: !!session,
    }}>
      {children}
    </AuthContext.Provider>
  );
};
