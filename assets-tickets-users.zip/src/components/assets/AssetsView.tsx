import React, { useState, useMemo } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import type { Asset, AssetStatus } from '@/lib/types';
import {
  Monitor, Search, Filter, Plus, ChevronDown, Package, AlertTriangle,
  ShieldAlert, Eye, Edit, MapPin, User, Tag, ArrowUpDown, X, Download
} from 'lucide-react';

const statusConfig: Record<AssetStatus, { label: string; color: string; bg: string }> = {
  in_use: { label: 'In Use', color: 'text-blue-700', bg: 'bg-blue-100' },
  assigned: { label: 'Assigned', color: 'text-indigo-700', bg: 'bg-indigo-100' },
  available: { label: 'Available', color: 'text-emerald-700', bg: 'bg-emerald-100' },
  in_stock: { label: 'In Stock', color: 'text-teal-700', bg: 'bg-teal-100' },
  lost: { label: 'Lost', color: 'text-orange-700', bg: 'bg-orange-100' },
  stolen: { label: 'Stolen', color: 'text-red-700', bg: 'bg-red-100' },
  unavailable: { label: 'Unavailable', color: 'text-gray-700', bg: 'bg-gray-200' },
};

const AssetsView: React.FC = () => {
  const { assets, users, departments, navigateTo, createAsset, updateAsset } = useAppContext();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [categoryFilter, setCategoryFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('asset_tag');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [showStatusModal, setShowStatusModal] = useState<Asset | null>(null);
  const [newStatus, setNewStatus] = useState<AssetStatus>('available');
  const [statusNote, setStatusNote] = useState('');
  const [assignUserId, setAssignUserId] = useState('');

  const categories = useMemo(() => [...new Set(assets.map(a => a.category))].sort(), [assets]);

  const filtered = useMemo(() => {
    let result = assets.filter(a => {
      const matchSearch = search === '' || 
        a.name.toLowerCase().includes(search.toLowerCase()) ||
        a.asset_tag.toLowerCase().includes(search.toLowerCase()) ||
        a.make.toLowerCase().includes(search.toLowerCase()) ||
        a.model.toLowerCase().includes(search.toLowerCase()) ||
        a.serial_number?.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'all' || a.status === statusFilter;
      const matchCategory = categoryFilter === 'all' || a.category === categoryFilter;
      const matchDept = departmentFilter === 'all' || a.department_id === departmentFilter;
      return matchSearch && matchStatus && matchCategory && matchDept;
    });
    result.sort((a, b) => {
      const aVal = (a as any)[sortBy] || '';
      const bVal = (b as any)[sortBy] || '';
      return sortDir === 'asc' ? String(aVal).localeCompare(String(bVal)) : String(bVal).localeCompare(String(aVal));
    });
    return result;
  }, [assets, search, statusFilter, categoryFilter, departmentFilter, sortBy, sortDir]);

  const inventorySummary = useMemo(() => {
    const summary: Record<string, { total: number; available: number; inUse: number; issues: number }> = {};
    assets.forEach(a => {
      if (!summary[a.category]) summary[a.category] = { total: 0, available: 0, inUse: 0, issues: 0 };
      summary[a.category].total++;
      if (a.status === 'available' || a.status === 'in_stock') summary[a.category].available++;
      if (a.status === 'in_use' || a.status === 'assigned') summary[a.category].inUse++;
      if (a.status === 'lost' || a.status === 'stolen' || a.status === 'unavailable') summary[a.category].issues++;
    });
    return summary;
  }, [assets]);

  const toggleSort = (field: string) => {
    if (sortBy === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortBy(field); setSortDir('asc'); }
  };

  const handleStatusChange = async () => {
    if (!showStatusModal) return;
    const updates: Partial<Asset> = { status: newStatus };
    if (newStatus === 'unavailable') updates.status_note = statusNote;
    if (newStatus === 'in_use' || newStatus === 'assigned') updates.assigned_user_id = assignUserId || null;
    else updates.assigned_user_id = null;
    if (newStatus === 'available' || newStatus === 'in_stock') { updates.status_note = null; updates.assigned_user_id = null; }
    await updateAsset(showStatusModal.id, updates);
    setShowStatusModal(null);
    setStatusNote('');
    setAssignUserId('');
  };

  const [newAsset, setNewAsset] = useState({ asset_tag: '', name: '', category: 'Laptop', make: '', model: '', serial_number: '', building: '', room: '', purchase_cost: '', department_id: '' });

  const handleCreate = async () => {
    if (!newAsset.asset_tag || !newAsset.name) return;
    await createAsset({
      ...newAsset,
      status: 'available' as AssetStatus,
      purchase_cost: parseFloat(newAsset.purchase_cost) || 0,
      purchase_date: new Date().toISOString().split('T')[0],
    } as any);
    setShowCreateModal(false);
    setNewAsset({ asset_tag: '', name: '', category: 'Laptop', make: '', model: '', serial_number: '', building: '', room: '', purchase_cost: '', department_id: '' });
  };

  const getUserName = (id: string | null) => {
    if (!id) return '-';
    const u = users.find(u => u.id === id);
    return u ? u.full_name : '-';
  };

  const getDeptName = (id: string) => departments.find(d => d.id === id)?.name || '-';

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Asset Management</h1>
          <p className="text-sm text-gray-500 mt-1">{assets.length} total assets across {categories.length} categories</p>
        </div>
        <button onClick={() => setShowCreateModal(true)} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center gap-2">
          <Plus className="w-4 h-4" /> Add Asset
        </button>
      </div>

      {/* Inventory Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
        {Object.entries(inventorySummary).map(([cat, data]) => (
          <div key={cat} className="bg-white rounded-xl border border-gray-200 p-3 hover:shadow-md transition-shadow cursor-pointer" onClick={() => setCategoryFilter(cat)}>
            <p className="text-xs font-medium text-gray-500 truncate">{cat}</p>
            <p className="text-xl font-bold text-gray-900 mt-1">{data.total}</p>
            <div className="flex items-center gap-2 mt-1">
              <span className="text-xs text-emerald-600">{data.available} avail</span>
              {data.issues > 0 && <span className="text-xs text-red-600">{data.issues} issue</span>}
            </div>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input type="text" placeholder="Search assets..." value={search} onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
          </div>
          <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white">
            <option value="all">All Statuses</option>
            {Object.entries(statusConfig).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
          <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white">
            <option value="all">All Categories</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
          <select value={departmentFilter} onChange={e => setDepartmentFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white">
            <option value="all">All Departments</option>
            {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          {(statusFilter !== 'all' || categoryFilter !== 'all' || departmentFilter !== 'all' || search) && (
            <button onClick={() => { setStatusFilter('all'); setCategoryFilter('all'); setDepartmentFilter('all'); setSearch(''); }}
              className="px-3 py-2 text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1">
              <X className="w-3 h-3" /> Clear
            </button>
          )}
        </div>
      </div>

      {/* Assets Table */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                {[
                  { key: 'asset_tag', label: 'Asset Tag' },
                  { key: 'name', label: 'Name' },
                  { key: 'category', label: 'Category' },
                  { key: 'status', label: 'Status' },
                  { key: 'assigned_user_id', label: 'Assigned To / Location' },
                  { key: 'department_id', label: 'Department' },
                  { key: 'condition', label: 'Condition' },
                ].map(col => (
                  <th key={col.key} className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase tracking-wider cursor-pointer hover:text-gray-700"
                    onClick={() => toggleSort(col.key)}>
                    <div className="flex items-center gap-1">
                      {col.label}
                      {sortBy === col.key && <ArrowUpDown className="w-3 h-3" />}
                    </div>
                  </th>
                ))}
                <th className="px-4 py-3 text-right text-xs font-semibold text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map(asset => {
                const sc = statusConfig[asset.status];
                return (
                  <tr key={asset.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <button onClick={() => navigateTo('asset-detail', asset.id)} className="text-sm font-mono font-medium text-blue-600 hover:text-blue-800">
                        {asset.asset_tag}
                      </button>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-gray-900">{asset.name}</p>
                      <p className="text-xs text-gray-500">{asset.make} {asset.model}</p>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-700">{asset.category}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => { setShowStatusModal(asset); setNewStatus(asset.status); setStatusNote(asset.status_note || ''); setAssignUserId(asset.assigned_user_id || ''); }}
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${sc.bg} ${sc.color} hover:opacity-80 transition-opacity`}>
                        {sc.label}
                        <ChevronDown className="w-3 h-3" />
                      </button>
                      {asset.status_note && <p className="text-xs text-gray-500 mt-1 max-w-[200px] truncate" title={asset.status_note}>{asset.status_note}</p>}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-700">
                      {(asset.status === 'in_use' || asset.status === 'assigned') ? (
                        <div className="flex items-center gap-1">
                          <User className="w-3 h-3 text-gray-400" />
                          <span>{getUserName(asset.assigned_user_id)}</span>
                        </div>
                      ) : (
                        <div className="flex items-center gap-1">
                          <MapPin className="w-3 h-3 text-gray-400" />
                          <span>{asset.building}, {asset.room}</span>
                        </div>
                      )}
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-700">{getDeptName(asset.department_id)}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs font-medium px-2 py-0.5 rounded ${
                        asset.condition === 'excellent' ? 'bg-emerald-100 text-emerald-700' :
                        asset.condition === 'good' ? 'bg-blue-100 text-blue-700' :
                        asset.condition === 'new' ? 'bg-purple-100 text-purple-700' :
                        'bg-orange-100 text-orange-700'
                      }`}>{asset.condition}</span>
                    </td>
                    <td className="px-4 py-3 text-right">
                      <button onClick={() => navigateTo('asset-detail', asset.id)} className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500 hover:text-gray-700">
                        <Eye className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">
          Showing {filtered.length} of {assets.length} assets
        </div>
      </div>

      {/* Status Change Modal */}
      {showStatusModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowStatusModal(null)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md mx-4" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-gray-900 mb-1">Change Asset Status</h3>
            <p className="text-sm text-gray-500 mb-4">{showStatusModal.asset_tag} - {showStatusModal.name}</p>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">New Status</label>
                <select value={newStatus} onChange={e => setNewStatus(e.target.value as AssetStatus)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  {Object.entries(statusConfig).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                </select>
              </div>
              {(newStatus === 'in_use' || newStatus === 'assigned') && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Assign to User</label>
                  <select value={assignUserId} onChange={e => setAssignUserId(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                    <option value="">Select user...</option>
                    {users.map(u => <option key={u.id} value={u.id}>{u.full_name} ({u.email})</option>)}
                  </select>
                </div>
              )}
              {newStatus === 'unavailable' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Reason / Note</label>
                  <textarea value={statusNote} onChange={e => setStatusNote(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" rows={3} placeholder="Explain why this asset is unavailable..." />
                </div>
              )}
              {(newStatus === 'lost' || newStatus === 'stolen') && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <div className="flex items-center gap-2">
                    <ShieldAlert className="w-4 h-4 text-red-600" />
                    <p className="text-sm font-medium text-red-800">
                      {newStatus === 'lost' ? 'Lost Device Workflow' : 'Stolen Device Workflow'}
                    </p>
                  </div>
                  <p className="text-xs text-red-600 mt-1">
                    {newStatus === 'lost' 
                      ? 'A lost device report will be generated and IT Security will be notified. Remote wipe will be initiated.'
                      : 'A theft report will be generated. IT Security and local authorities will be notified. Remote wipe will be initiated immediately.'}
                  </p>
                  <textarea value={statusNote} onChange={e => setStatusNote(e.target.value)}
                    className="w-full px-3 py-2 border border-red-300 rounded-lg text-sm mt-2 bg-white" rows={2} placeholder="Provide details about the incident..." />
                </div>
              )}
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowStatusModal(null)} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">Cancel</button>
              <button onClick={handleStatusChange} className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">Update Status</button>
            </div>
          </div>
        </div>
      )}

      {/* Create Asset Modal */}
      {showCreateModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowCreateModal(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Add New Asset</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Asset Tag *</label>
                <input type="text" value={newAsset.asset_tag} onChange={e => setNewAsset({...newAsset, asset_tag: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="IT-LAP-XXX" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                <input type="text" value={newAsset.name} onChange={e => setNewAsset({...newAsset, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Device name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select value={newAsset.category} onChange={e => setNewAsset({...newAsset, category: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  {['Laptop', 'Desktop', 'Monitor', 'Tablet', 'Phone', 'Printer', 'Network', 'Server', 'Furniture', 'Other'].map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Make</label>
                <input type="text" value={newAsset.make} onChange={e => setNewAsset({...newAsset, make: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Manufacturer" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Model</label>
                <input type="text" value={newAsset.model} onChange={e => setNewAsset({...newAsset, model: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Model name" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Serial Number</label>
                <input type="text" value={newAsset.serial_number} onChange={e => setNewAsset({...newAsset, serial_number: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Building</label>
                <input type="text" value={newAsset.building} onChange={e => setNewAsset({...newAsset, building: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Room</label>
                <input type="text" value={newAsset.room} onChange={e => setNewAsset({...newAsset, room: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Purchase Cost</label>
                <input type="number" value={newAsset.purchase_cost} onChange={e => setNewAsset({...newAsset, purchase_cost: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="0.00" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                <select value={newAsset.department_id} onChange={e => setNewAsset({...newAsset, department_id: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option value="">Select...</option>
                  {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowCreateModal(false)} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">Cancel</button>
              <button onClick={handleCreate} className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">Create Asset</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AssetsView;
