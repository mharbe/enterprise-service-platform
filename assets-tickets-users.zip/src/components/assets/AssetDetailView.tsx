import React, { useMemo } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import {
  ArrowLeft, Monitor, User, MapPin, Calendar, DollarSign, Shield, Tag,
  Ticket, Clock, AlertTriangle, FileText, Package
} from 'lucide-react';

const statusConfig: Record<string, { label: string; color: string; bg: string }> = {
  in_use: { label: 'In Use', color: 'text-blue-700', bg: 'bg-blue-100' },
  assigned: { label: 'Assigned', color: 'text-indigo-700', bg: 'bg-indigo-100' },
  available: { label: 'Available', color: 'text-emerald-700', bg: 'bg-emerald-100' },
  in_stock: { label: 'In Stock', color: 'text-teal-700', bg: 'bg-teal-100' },
  lost: { label: 'Lost', color: 'text-orange-700', bg: 'bg-orange-100' },
  stolen: { label: 'Stolen', color: 'text-red-700', bg: 'bg-red-100' },
  unavailable: { label: 'Unavailable', color: 'text-gray-700', bg: 'bg-gray-200' },
};

const AssetDetailView: React.FC = () => {
  const { selectedId, assets, users, departments, tickets, navigateTo } = useAppContext();
  const asset = assets.find(a => a.id === selectedId);

  const linkedTickets = useMemo(() => tickets.filter(t => t.asset_id === selectedId), [tickets, selectedId]);
  const assignedUser = useMemo(() => asset?.assigned_user_id ? users.find(u => u.id === asset.assigned_user_id) : null, [asset, users]);
  const dept = useMemo(() => asset ? departments.find(d => d.id === asset.department_id) : null, [asset, departments]);

  if (!asset) return (
    <div className="flex items-center justify-center h-64">
      <p className="text-gray-500">Asset not found</p>
    </div>
  );

  const sc = statusConfig[asset.status] || statusConfig.available;

  return (
    <div className="space-y-6">
      <button onClick={() => navigateTo('assets')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700">
        <ArrowLeft className="w-4 h-4" /> Back to Assets
      </button>

      {/* Header */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
              <Monitor className="w-7 h-7 text-white" />
            </div>
            <div>
              <div className="flex items-center gap-3">
                <h1 className="text-xl font-bold text-gray-900">{asset.name}</h1>
                <span className={`px-2.5 py-1 rounded-full text-xs font-medium ${sc.bg} ${sc.color}`}>{sc.label}</span>
              </div>
              <p className="text-sm text-gray-500 mt-1 font-mono">{asset.asset_tag} · S/N: {asset.serial_number}</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Details */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Asset Details</h3>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Tag, label: 'Category', value: asset.category },
                { icon: Package, label: 'Make / Model', value: `${asset.make} ${asset.model}` },
                { icon: Shield, label: 'Condition', value: asset.condition },
                { icon: MapPin, label: 'Location', value: `${asset.building}, Room ${asset.room}` },
                { icon: Calendar, label: 'Purchase Date', value: asset.purchase_date ? new Date(asset.purchase_date).toLocaleDateString() : '-' },
                { icon: DollarSign, label: 'Purchase Cost', value: asset.purchase_cost ? `$${Number(asset.purchase_cost).toLocaleString()}` : '-' },
                { icon: Calendar, label: 'Warranty Expiry', value: asset.warranty_expiry ? new Date(asset.warranty_expiry).toLocaleDateString() : '-' },
                { icon: FileText, label: 'Department', value: dept?.name || '-' },
              ].map((item, i) => {
                const Icon = item.icon;
                return (
                  <div key={i} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <Icon className="w-4 h-4 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">{item.label}</p>
                      <p className="text-sm font-medium text-gray-900">{item.value}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {asset.status_note && (
            <div className="bg-amber-50 border border-amber-200 rounded-xl p-4">
              <div className="flex items-center gap-2 mb-1">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <p className="text-sm font-medium text-amber-800">Status Note</p>
              </div>
              <p className="text-sm text-amber-700">{asset.status_note}</p>
            </div>
          )}

          {/* Linked Tickets */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Linked Tickets ({linkedTickets.length})</h3>
            {linkedTickets.length === 0 ? (
              <p className="text-sm text-gray-500">No tickets linked to this asset.</p>
            ) : (
              <div className="space-y-2">
                {linkedTickets.map(t => (
                  <button key={t.id} onClick={() => navigateTo('ticket-detail', t.id)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors text-left">
                    <Ticket className="w-4 h-4 text-gray-400" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{t.subject}</p>
                      <p className="text-xs text-gray-500">{t.ticket_number} · {t.status.replace('_', ' ')}</p>
                    </div>
                    <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${
                      t.priority === 'critical' ? 'bg-red-100 text-red-700' :
                      t.priority === 'high' ? 'bg-orange-100 text-orange-700' :
                      t.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-green-100 text-green-700'
                    }`}>{t.priority}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {assignedUser && (
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="text-sm font-semibold text-gray-900 mb-4">Assigned User</h3>
              <button onClick={() => navigateTo('user-detail', assignedUser.id)} className="flex items-center gap-3 hover:bg-gray-50 p-2 rounded-lg w-full text-left">
                <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center text-white font-bold text-sm">
                  {assignedUser.first_name[0]}{assignedUser.last_name[0]}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{assignedUser.full_name}</p>
                  <p className="text-xs text-gray-500">{assignedUser.title}</p>
                  <p className="text-xs text-gray-500">{assignedUser.email}</p>
                </div>
              </button>
            </div>
          )}

          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Timeline</h3>
            <div className="space-y-4">
              <div className="flex gap-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-1.5 flex-shrink-0" />
                <div>
                  <p className="text-sm text-gray-900">Asset created</p>
                  <p className="text-xs text-gray-500">{new Date(asset.created_at).toLocaleDateString()}</p>
                </div>
              </div>
              {asset.assigned_user_id && (
                <div className="flex gap-3">
                  <div className="w-2 h-2 bg-emerald-500 rounded-full mt-1.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-900">Assigned to {assignedUser?.full_name}</p>
                    <p className="text-xs text-gray-500">{new Date(asset.updated_at).toLocaleDateString()}</p>
                  </div>
                </div>
              )}
              {linkedTickets.map(t => (
                <div key={t.id} className="flex gap-3">
                  <div className="w-2 h-2 bg-amber-500 rounded-full mt-1.5 flex-shrink-0" />
                  <div>
                    <p className="text-sm text-gray-900">Ticket: {t.subject}</p>
                    <p className="text-xs text-gray-500">{new Date(t.created_at).toLocaleDateString()}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AssetDetailView;
