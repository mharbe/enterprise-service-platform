import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import {
  Plug, Plus, Settings, CheckCircle2, XCircle, Clock, RefreshCw, ExternalLink,
  Shield, Users, Monitor, Globe, X, Loader2, Link2
} from 'lucide-react';

interface IntegrationConfig {
  name: string;
  type: string;
  icon: string;
  description: string;
  capabilities: string[];
  fields: { key: string; label: string; type: string; placeholder: string; required?: boolean }[];
}

const integrationConfigs: IntegrationConfig[] = [
  {
    name: 'Active Directory', type: 'active_directory', icon: '🔐',
    description: 'Sync users and groups from on-premises Active Directory',
    capabilities: ['User Sync', 'Group Sync', 'Authentication'],
    fields: [
      { key: 'domain', label: 'Domain', type: 'text', placeholder: 'company.local', required: true },
      { key: 'ldap_url', label: 'LDAP URL', type: 'text', placeholder: 'ldap://dc01.company.local', required: true },
      { key: 'bind_dn', label: 'Bind DN', type: 'text', placeholder: 'CN=ServiceAccount,OU=...' },
      { key: 'bind_password', label: 'Bind Password', type: 'password', placeholder: '' },
      { key: 'base_dn', label: 'Base DN', type: 'text', placeholder: 'DC=company,DC=local' },
    ],
  },
  {
    name: 'Microsoft Entra ID', type: 'entra_id', icon: '☁️',
    description: 'Sync users, groups, and devices from Azure AD / Entra ID',
    capabilities: ['User Sync', 'Device Sync', 'Group Sync', 'SSO'],
    fields: [
      { key: 'tenant_id', label: 'Tenant ID', type: 'text', placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx', required: true },
      { key: 'client_id', label: 'Client ID', type: 'text', placeholder: 'Application (client) ID', required: true },
      { key: 'client_secret', label: 'Client Secret', type: 'password', placeholder: '' },
    ],
  },
  {
    name: 'Microsoft Intune', type: 'intune', icon: '📱',
    description: 'Pull managed devices and compliance status from Intune',
    capabilities: ['Device Sync', 'Compliance Status', 'App Inventory'],
    fields: [
      { key: 'tenant_id', label: 'Tenant ID', type: 'text', placeholder: 'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx', required: true },
      { key: 'client_id', label: 'Client ID', type: 'text', placeholder: 'Application (client) ID', required: true },
      { key: 'client_secret', label: 'Client Secret', type: 'password', placeholder: '' },
    ],
  },
  {
    name: 'Mosyle', type: 'mosyle', icon: '🍎',
    description: 'Sync Apple devices managed through Mosyle MDM',
    capabilities: ['Device Sync', 'App Management', 'User Sync'],
    fields: [
      { key: 'api_token', label: 'API Token', type: 'password', placeholder: 'Your Mosyle API token', required: true },
      { key: 'email', label: 'Admin Email', type: 'email', placeholder: 'admin@company.com' },
      { key: 'password', label: 'Admin Password', type: 'password', placeholder: '' },
    ],
  },
  {
    name: 'Jamf Pro', type: 'jamf', icon: '🖥️',
    description: 'Pull Apple device inventory from Jamf Pro',
    capabilities: ['Device Sync', 'User Sync', 'App Inventory', 'Compliance'],
    fields: [
      { key: 'url', label: 'Jamf Pro URL', type: 'text', placeholder: 'https://company.jamfcloud.com', required: true },
      { key: 'client_id', label: 'Client ID', type: 'text', placeholder: 'API client ID', required: true },
      { key: 'client_secret', label: 'Client Secret', type: 'password', placeholder: '' },
    ],
  },
  {
    name: 'Google Workspace', type: 'google_workspace', icon: '🔵',
    description: 'Sync users, groups, and Chrome devices from Google Workspace',
    capabilities: ['User Sync', 'Device Sync', 'Group Sync', 'Chrome Devices'],
    fields: [
      { key: 'domain', label: 'Domain', type: 'text', placeholder: 'company.com', required: true },
      { key: 'service_account_email', label: 'Service Account Email', type: 'email', placeholder: 'sa@project.iam.gserviceaccount.com', required: true },
      { key: 'private_key', label: 'Private Key (JSON)', type: 'password', placeholder: 'Paste service account JSON key' },
      { key: 'admin_email', label: 'Admin Email', type: 'email', placeholder: 'admin@company.com' },
    ],
  },
  {
    name: 'Custom MDM / API', type: 'custom', icon: '🔧',
    description: 'Connect any MDM or user management platform via custom API',
    capabilities: ['User Sync', 'Device Sync', 'Custom Mapping'],
    fields: [
      { key: 'api_url', label: 'API Base URL', type: 'text', placeholder: 'https://api.example.com/v1', required: true },
      { key: 'api_key', label: 'API Key', type: 'password', placeholder: 'Your API key' },
      { key: 'auth_type', label: 'Auth Type', type: 'text', placeholder: 'bearer / basic / api_key' },
      { key: 'sync_type', label: 'Sync Type', type: 'text', placeholder: 'users / devices / both' },
    ],
  },
];

const IntegrationsView: React.FC = () => {
  const { integrations, refreshData } = useAppContext();
  const [showSetup, setShowSetup] = useState<IntegrationConfig | null>(null);
  const [configValues, setConfigValues] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState(false);
  const [syncing, setSyncing] = useState<string | null>(null);

  const handleSave = async () => {
    if (!showSetup) return;
    setSaving(true);
    const { error } = await supabase.from('integrations').insert({
      name: showSetup.name,
      type: showSetup.type,
      config: configValues,
      status: 'configured',
    });
    setSaving(false);
    if (error) { toast.error('Failed to save integration'); return; }
    toast.success(`${showSetup.name} integration configured`);
    setShowSetup(null);
    setConfigValues({});
    await refreshData();
  };

  const handleSync = async (id: string) => {
    setSyncing(id);
    // Simulate sync
    await new Promise(r => setTimeout(r, 2000));
    await supabase.from('integrations').update({ last_sync: new Date().toISOString(), status: 'connected' }).eq('id', id);
    toast.success('Sync completed successfully');
    setSyncing(null);
    await refreshData();
  };

  const handleDisconnect = async (id: string) => {
    await supabase.from('integrations').update({ status: 'disconnected' }).eq('id', id);
    toast.success('Integration disconnected');
    await refreshData();
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'connected': return <span className="flex items-center gap-1 text-xs font-medium text-green-700 bg-green-100 px-2 py-0.5 rounded-full"><CheckCircle2 className="w-3 h-3" /> Connected</span>;
      case 'configured': return <span className="flex items-center gap-1 text-xs font-medium text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full"><Clock className="w-3 h-3" /> Configured</span>;
      default: return <span className="flex items-center gap-1 text-xs font-medium text-gray-600 bg-gray-100 px-2 py-0.5 rounded-full"><XCircle className="w-3 h-3" /> Disconnected</span>;
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Integrations</h1>
        <p className="text-sm text-gray-500 mt-1">Connect your identity providers, MDMs, and external platforms</p>
      </div>

      {/* Active Integrations */}
      {integrations.length > 0 && (
        <div>
          <h2 className="text-sm font-semibold text-gray-900 mb-3">Active Integrations</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {integrations.map(int => (
              <div key={int.id} className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-sm font-semibold text-gray-900">{int.name}</h3>
                  {getStatusBadge(int.status)}
                </div>
                <p className="text-xs text-gray-500 mb-3">Type: {int.type}</p>
                {int.last_sync && <p className="text-xs text-gray-500 mb-3">Last sync: {new Date(int.last_sync).toLocaleString()}</p>}
                <div className="flex gap-2">
                  <button onClick={() => handleSync(int.id)} disabled={syncing === int.id}
                    className="flex-1 px-3 py-1.5 bg-blue-50 text-blue-700 rounded-lg text-xs font-medium hover:bg-blue-100 flex items-center justify-center gap-1">
                    {syncing === int.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                    Sync Now
                  </button>
                  <button onClick={() => handleDisconnect(int.id)}
                    className="px-3 py-1.5 bg-red-50 text-red-700 rounded-lg text-xs font-medium hover:bg-red-100">
                    Disconnect
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Available Integrations */}
      <div>
        <h2 className="text-sm font-semibold text-gray-900 mb-3">Available Integrations</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {integrationConfigs.map(config => {
            const isConfigured = integrations.some(i => i.type === config.type);
            return (
              <div key={config.type} className={`bg-white rounded-xl border p-5 transition-all ${isConfigured ? 'border-green-200 bg-green-50/30' : 'border-gray-200 hover:border-gray-300 hover:shadow-md'}`}>
                <div className="flex items-center gap-3 mb-3">
                  <span className="text-2xl">{config.icon}</span>
                  <div>
                    <h3 className="text-sm font-semibold text-gray-900">{config.name}</h3>
                    {isConfigured && <span className="text-xs text-green-600 font-medium">Already configured</span>}
                  </div>
                </div>
                <p className="text-xs text-gray-600 mb-3">{config.description}</p>
                <div className="flex flex-wrap gap-1 mb-4">
                  {config.capabilities.map(cap => (
                    <span key={cap} className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">{cap}</span>
                  ))}
                </div>
                <button onClick={() => { setShowSetup(config); setConfigValues({}); }}
                  className={`w-full px-3 py-2 rounded-lg text-xs font-medium flex items-center justify-center gap-1 ${
                    isConfigured ? 'bg-gray-100 text-gray-600 hover:bg-gray-200' : 'bg-blue-600 text-white hover:bg-blue-700'
                  }`}>
                  <Link2 className="w-3 h-3" />
                  {isConfigured ? 'Reconfigure' : 'Connect'}
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Setup Modal */}
      {showSetup && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowSetup(null)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-lg mx-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <span className="text-2xl">{showSetup.icon}</span>
                <div>
                  <h3 className="text-lg font-semibold text-gray-900">Configure {showSetup.name}</h3>
                  <p className="text-xs text-gray-500">{showSetup.description}</p>
                </div>
              </div>
              <button onClick={() => setShowSetup(null)} className="p-1 rounded hover:bg-gray-100"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              {showSetup.fields.map(field => (
                <div key={field.key}>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    {field.label} {field.required && <span className="text-red-500">*</span>}
                  </label>
                  <input
                    type={field.type}
                    value={configValues[field.key] || ''}
                    onChange={e => setConfigValues({...configValues, [field.key]: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm"
                    placeholder={field.placeholder}
                  />
                </div>
              ))}
            </div>
            <div className="mt-4 p-3 bg-amber-50 border border-amber-200 rounded-lg">
              <p className="text-xs text-amber-800">Credentials are encrypted and stored securely. Ensure the service account has appropriate read permissions.</p>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowSetup(null)} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">Cancel</button>
              <button onClick={handleSave} disabled={saving}
                className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2">
                {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Plug className="w-4 h-4" />}
                {saving ? 'Saving...' : 'Save & Connect'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default IntegrationsView;
