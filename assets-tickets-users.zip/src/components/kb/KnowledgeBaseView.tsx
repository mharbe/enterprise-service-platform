import React, { useState, useMemo, useEffect, useRef } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import {
  Search, BookOpen, Eye, ThumbsUp, Tag, Plus, ArrowLeft, X, Sparkles, Loader2, Clock
} from 'lucide-react';

const KnowledgeBaseView: React.FC = () => {
  const { kbArticles, departments, navigateTo, currentView, selectedId, createKBArticle } = useAppContext();
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [showCreate, setShowCreate] = useState(false);
  const [newArticle, setNewArticle] = useState({ title: '', content: '', category: '', tags: '' });
  const [aiGenerating, setAiGenerating] = useState(false);
  const viewIncrementedRef = useRef<string | null>(null);

  const categories = useMemo(() => [...new Set(kbArticles.map(a => a.category))].sort(), [kbArticles]);

  const filtered = useMemo(() => {
    return kbArticles.filter(a => {
      const matchSearch = search === '' ||
        a.title.toLowerCase().includes(search.toLowerCase()) ||
        a.content.toLowerCase().includes(search.toLowerCase()) ||
        a.tags?.some(t => t.toLowerCase().includes(search.toLowerCase()));
      const matchCat = categoryFilter === 'all' || a.category === categoryFilter;
      return matchSearch && matchCat;
    });
  }, [kbArticles, search, categoryFilter]);

  // Increment view count when viewing article detail
  useEffect(() => {
    if (currentView === 'kb-article' && selectedId && viewIncrementedRef.current !== selectedId) {
      const article = kbArticles.find(a => a.id === selectedId);
      if (article) {
        viewIncrementedRef.current = selectedId;
        supabase.from('kb_articles').update({ views: article.views + 1 }).eq('id', article.id);
      }
    }
  }, [currentView, selectedId, kbArticles]);

  // Article detail view
  if (currentView === 'kb-article' && selectedId) {
    const article = kbArticles.find(a => a.id === selectedId);
    if (!article) return <div className="text-center py-12"><p className="text-gray-500">Article not found</p></div>;

    const handleHelpful = async () => {
      await supabase.from('kb_articles').update({ helpful_count: article.helpful_count + 1 }).eq('id', article.id);
    };

    return (
      <div className="max-w-4xl mx-auto space-y-6">
        <button onClick={() => navigateTo('kb')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700">
          <ArrowLeft className="w-4 h-4" /> Back to Knowledge Base
        </button>
        <div className="bg-white rounded-xl border border-gray-200 p-8">
          <div className="flex items-center gap-2 mb-4">
            <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">{article.category}</span>
            {article.tags?.map(tag => (
              <span key={tag} className="px-2 py-0.5 bg-gray-100 text-gray-600 rounded text-xs">{tag}</span>
            ))}
          </div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">{article.title}</h1>
          <div className="flex items-center gap-4 text-xs text-gray-500 mb-6">
            <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {article.views} views</span>
            <span className="flex items-center gap-1"><ThumbsUp className="w-3 h-3" /> {article.helpful_count} found helpful</span>
            <span className="flex items-center gap-1"><Clock className="w-3 h-3" /> Updated {new Date(article.updated_at).toLocaleDateString()}</span>
          </div>
          <div className="prose prose-sm max-w-none">
            {article.content.split('\n').map((line, i) => (
              <p key={i} className={`text-sm text-gray-700 ${line.startsWith('#') ? 'font-semibold text-gray-900 text-base mt-4' : line.startsWith('-') || line.startsWith('•') ? 'pl-4' : ''}`}>
                {line}
              </p>
            ))}
          </div>
          <div className="mt-8 pt-6 border-t border-gray-200 flex items-center justify-between">
            <p className="text-sm text-gray-600">Was this article helpful?</p>
            <button onClick={handleHelpful} className="px-4 py-2 bg-green-50 text-green-700 border border-green-200 rounded-lg text-sm font-medium hover:bg-green-100 flex items-center gap-2">
              <ThumbsUp className="w-4 h-4" /> Yes, this helped
            </button>
          </div>
        </div>
      </div>
    );
  }


  const handleCreate = async () => {
    if (!newArticle.title || !newArticle.content) return;
    await createKBArticle({
      ...newArticle,
      tags: newArticle.tags.split(',').map(t => t.trim()).filter(Boolean),
      status: 'published',
      views: 0,
      helpful_count: 0,
    } as any);
    setShowCreate(false);
    setNewArticle({ title: '', content: '', category: '', tags: '' });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Knowledge Base</h1>
          <p className="text-sm text-gray-500 mt-1">{kbArticles.length} articles · {kbArticles.reduce((s, a) => s + a.views, 0)} total views</p>
        </div>
        <button onClick={() => setShowCreate(true)} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Article
        </button>
      </div>

      {/* Search & Filter */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input type="text" placeholder="Search articles..." value={search} onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" />
          </div>
          <select value={categoryFilter} onChange={e => setCategoryFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white">
            <option value="all">All Categories</option>
            {categories.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        </div>
      </div>

      {/* Category Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
        {categories.map(cat => {
          const count = kbArticles.filter(a => a.category === cat).length;
          return (
            <button key={cat} onClick={() => setCategoryFilter(cat === categoryFilter ? 'all' : cat)}
              className={`p-3 rounded-xl border text-left transition-all ${categoryFilter === cat ? 'bg-blue-50 border-blue-300' : 'bg-white border-gray-200 hover:border-gray-300'}`}>
              <p className="text-xs font-medium text-gray-500">{cat}</p>
              <p className="text-lg font-bold text-gray-900">{count}</p>
            </button>
          );
        })}
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(article => (
          <button key={article.id} onClick={() => navigateTo('kb-article', article.id)}
            className="bg-white rounded-xl border border-gray-200 p-5 text-left hover:shadow-lg transition-all hover:border-gray-300 group">
            <div className="flex items-center gap-2 mb-3">
              <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded text-xs font-medium">{article.category}</span>
            </div>
            <h3 className="text-sm font-semibold text-gray-900 group-hover:text-blue-600 transition-colors mb-2">{article.title}</h3>
            <p className="text-xs text-gray-500 line-clamp-2 mb-4">{article.content.substring(0, 120)}...</p>
            <div className="flex items-center gap-4 text-xs text-gray-400">
              <span className="flex items-center gap-1"><Eye className="w-3 h-3" /> {article.views}</span>
              <span className="flex items-center gap-1"><ThumbsUp className="w-3 h-3" /> {article.helpful_count}</span>
            </div>
            {article.tags && article.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-3">
                {article.tags.slice(0, 3).map(tag => (
                  <span key={tag} className="px-1.5 py-0.5 bg-gray-100 text-gray-500 rounded text-xs">{tag}</span>
                ))}
              </div>
            )}
          </button>
        ))}
      </div>

      {/* Create Modal */}
      {showCreate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowCreate(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">Create KB Article</h3>
              <button onClick={() => setShowCreate(false)} className="p-1 rounded hover:bg-gray-100"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Title *</label>
                <input type="text" value={newArticle.title} onChange={e => setNewArticle({...newArticle, title: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                  <input type="text" value={newArticle.category} onChange={e => setNewArticle({...newArticle, category: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="e.g., Network, Hardware" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Tags (comma-separated)</label>
                  <input type="text" value={newArticle.tags} onChange={e => setNewArticle({...newArticle, tags: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="wifi, network, troubleshooting" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Content *</label>
                <textarea value={newArticle.content} onChange={e => setNewArticle({...newArticle, content: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm font-mono" rows={12} placeholder="Article content..." />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowCreate(false)} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">Cancel</button>
              <button onClick={handleCreate} className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">Publish Article</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default KnowledgeBaseView;
