import React, { useState, useMemo } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { ArrowLeft, Mail, MapPin, Building2, Phone, Monitor, Ticket, Edit, Save, X, User as UserIcon } from 'lucide-react';

const UserDetailView: React.FC = () => {
  const { selectedId, users, departments, assets, tickets, navigateTo, updateUser } = useAppContext();
  const user = users.find(u => u.id === selectedId);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState<any>({});

  const assignedAssets = useMemo(() => assets.filter(a => a.assigned_user_id === selectedId), [assets, selectedId]);
  const userTickets = useMemo(() => tickets.filter(t => t.requester_email === user?.email), [tickets, user]);
  const dept = useMemo(() => user ? departments.find(d => d.id === user.department_id) : null, [user, departments]);
  const supervisor = useMemo(() => user?.supervisor_id ? users.find(u => u.id === user.supervisor_id) : null, [user, users]);

  if (!user) return <div className="flex items-center justify-center h-64"><p className="text-gray-500">User not found</p></div>;

  const startEdit = () => { setEditForm({ ...user }); setEditing(true); };
  const handleSave = async () => {
    const { id, full_name, created_at, updated_at, department, supervisor: s, ...updates } = editForm;
    await updateUser(user.id, updates);
    setEditing(false);
  };

  return (
    <div className="space-y-6">
      <button onClick={() => navigateTo('users')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700">
        <ArrowLeft className="w-4 h-4" /> Back to Users
      </button>

      {/* Header */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-full flex items-center justify-center text-white font-bold text-xl"
              style={{ background: `linear-gradient(135deg, ${dept?.color || '#6B7280'}, ${dept?.color || '#6B7280'}99)` }}>
              {user.first_name[0]}{user.last_name[0]}
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">{user.full_name}</h1>
              <p className="text-sm text-gray-500">{user.title} · {dept?.name}</p>
              <div className="flex items-center gap-3 mt-2">
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${user.status === 'active' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>{user.status}</span>
                <span className={`px-2 py-0.5 rounded text-xs font-medium ${
                  user.role === 'admin' ? 'bg-red-100 text-red-700' : user.role === 'manager' ? 'bg-purple-100 text-purple-700' : user.role === 'technician' ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 text-gray-600'
                }`}>{user.role}</span>
                <span className="text-xs text-gray-500">Source: {user.source}</span>
              </div>
            </div>
          </div>
          <button onClick={editing ? handleSave : startEdit}
            className={`px-4 py-2 rounded-lg text-sm font-medium flex items-center gap-2 ${editing ? 'bg-green-600 text-white hover:bg-green-700' : 'bg-gray-100 text-gray-700 hover:bg-gray-200'}`}>
            {editing ? <><Save className="w-4 h-4" /> Save</> : <><Edit className="w-4 h-4" /> Edit</>}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          {/* Contact Info */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Contact Information</h3>
            {editing ? (
              <div className="grid grid-cols-2 gap-4">
                {[
                  { key: 'first_name', label: 'First Name' }, { key: 'last_name', label: 'Last Name' },
                  { key: 'email', label: 'Email' }, { key: 'phone', label: 'Phone' },
                  { key: 'title', label: 'Title' }, { key: 'role', label: 'Role', type: 'select', options: ['user', 'technician', 'manager', 'admin'] },
                ].map(field => (
                  <div key={field.key}>
                    <label className="block text-xs font-medium text-gray-700 mb-1">{field.label}</label>
                    {field.type === 'select' ? (
                      <select value={editForm[field.key] || ''} onChange={e => setEditForm({...editForm, [field.key]: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                        {field.options?.map(o => <option key={o} value={o}>{o}</option>)}
                      </select>
                    ) : (
                      <input type="text" value={editForm[field.key] || ''} onChange={e => setEditForm({...editForm, [field.key]: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {[
                  { icon: Mail, label: 'Email', value: user.email },
                  { icon: Phone, label: 'Phone', value: user.phone || '-' },
                  { icon: Building2, label: 'Department', value: dept?.name || '-' },
                  { icon: UserIcon, label: 'Title', value: user.title || '-' },
                ].map((item, i) => {
                  const Icon = item.icon;
                  return (
                    <div key={i} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                      <Icon className="w-4 h-4 text-gray-400 mt-0.5" />
                      <div>
                        <p className="text-xs text-gray-500">{item.label}</p>
                        <p className="text-sm font-medium text-gray-900">{item.value}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Location */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Location</h3>
            {editing ? (
              <div className="grid grid-cols-2 gap-4">
                {['town', 'state', 'building', 'room'].map(key => (
                  <div key={key}>
                    <label className="block text-xs font-medium text-gray-700 mb-1 capitalize">{key}</label>
                    <input type="text" value={editForm[key] || ''} onChange={e => setEditForm({...editForm, [key]: e.target.value})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {[
                  { label: 'Town', value: user.town || '-' },
                  { label: 'State', value: user.state || '-' },
                  { label: 'Building', value: user.building || '-' },
                  { label: 'Room', value: user.room || '-' },
                ].map(item => (
                  <div key={item.label} className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-xs text-gray-500">{item.label}</p>
                    <p className="text-sm font-medium text-gray-900">{item.value}</p>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Assigned Assets */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Assigned Assets ({assignedAssets.length})</h3>
            {assignedAssets.length === 0 ? <p className="text-sm text-gray-500">No assets assigned.</p> : (
              <div className="space-y-2">
                {assignedAssets.map(a => (
                  <button key={a.id} onClick={() => navigateTo('asset-detail', a.id)}
                    className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-gray-50 text-left">
                    <Monitor className="w-5 h-5 text-gray-400" />
                    <div className="flex-1">
                      <p className="text-sm font-medium text-gray-900">{a.name}</p>
                      <p className="text-xs text-gray-500">{a.asset_tag} · {a.category}</p>
                    </div>
                    <span className="text-xs font-medium text-blue-600">{a.status.replace('_', ' ')}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {supervisor && (
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">Supervisor</h3>
              <button onClick={() => navigateTo('user-detail', supervisor.id)} className="flex items-center gap-3 hover:bg-gray-50 p-2 rounded-lg w-full text-left">
                <div className="w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center text-white text-xs font-bold">
                  {supervisor.first_name[0]}{supervisor.last_name[0]}
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-900">{supervisor.full_name}</p>
                  <p className="text-xs text-gray-500">{supervisor.title}</p>
                </div>
              </button>
            </div>
          )}

          {/* Recent Tickets */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Recent Tickets ({userTickets.length})</h3>
            {userTickets.length === 0 ? <p className="text-sm text-gray-500">No tickets.</p> : (
              <div className="space-y-2">
                {userTickets.slice(0, 5).map(t => (
                  <button key={t.id} onClick={() => navigateTo('ticket-detail', t.id)}
                    className="w-full text-left p-2 rounded-lg hover:bg-gray-50">
                    <p className="text-sm font-medium text-gray-900 truncate">{t.subject}</p>
                    <p className="text-xs text-gray-500">{t.ticket_number} · {t.status.replace('_', ' ')}</p>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default UserDetailView;
