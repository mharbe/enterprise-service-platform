import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import type { ViewType } from '@/lib/types';
import {
  LayoutDashboard, Monitor, Ticket, Users, BookOpen, Plug, Settings,
  ChevronLeft, ChevronRight, PlusCircle, MessageSquare, Shield, LogIn, LogOut, X, Loader2, UserPlus
} from 'lucide-react';

const menuItems: { id: ViewType; label: string; icon: React.ElementType; module?: string }[] = [
  { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { id: 'tickets', label: 'Tickets', icon: Ticket, module: 'tickets' },
  { id: 'assets', label: 'Assets', icon: Monitor, module: 'assets' },
  { id: 'users', label: 'Users', icon: Users, module: 'users' },
  { id: 'kb', label: 'Knowledge Base', icon: BookOpen, module: 'kb' },
  { id: 'integrations', label: 'Integrations', icon: Plug, module: 'integrations' },
  { id: 'settings', label: 'Settings & Roles', icon: Settings, module: 'settings' },
];

const Sidebar: React.FC = () => {
  const { sidebarOpen, toggleSidebar, currentView, navigateTo, tickets } = useAppContext();
  const { isAuthenticated, managedUser, signIn, signUp, signOut, can, loading: authLoading } = useAuth();
  const openTickets = tickets.filter(t => t.status === 'open' || t.status === 'in_progress').length;

  const [showAuthModal, setShowAuthModal] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [authError, setAuthError] = useState('');
  const [authLoading2, setAuthLoading2] = useState(false);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError('');
    setAuthLoading2(true);
    let err: string | null;
    if (authMode === 'login') {
      err = await signIn(email, password);
    } else {
      if (!firstName || !lastName) { setAuthError('First and last name are required'); setAuthLoading2(false); return; }
      err = await signUp(email, password, firstName, lastName);
    }
    setAuthLoading2(false);
    if (err) { setAuthError(err); return; }
    setShowAuthModal(false);
    setEmail(''); setPassword(''); setFirstName(''); setLastName('');
  };

  const visibleMenuItems = menuItems.filter(item => {
    if (!item.module) return true; // dashboard always visible
    if (!isAuthenticated) return item.id === 'kb'; // unauthenticated users see KB only
    return can(item.module, 'view');
  });

  return (
    <>
      <aside className={`${sidebarOpen ? 'w-64' : 'w-16'} bg-slate-900 text-white flex flex-col transition-all duration-300 flex-shrink-0 h-screen sticky top-0`}>
        {/* Logo */}
        <div className="flex items-center justify-between p-4 border-b border-slate-700">
          {sidebarOpen && (
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-sm font-bold tracking-tight">ServiceDesk</h1>
                <p className="text-[10px] text-slate-400">Enterprise Platform</p>
              </div>
            </div>
          )}
          <button onClick={toggleSidebar} className="p-1.5 rounded-lg hover:bg-slate-700 transition-colors">
            {sidebarOpen ? <ChevronLeft className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
          </button>
        </div>

        {/* Quick Actions */}
        {sidebarOpen && isAuthenticated && can('tickets', 'create') && (
          <div className="p-3 border-b border-slate-700">
            <button
              onClick={() => navigateTo('ticket-create')}
              className="w-full flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm font-medium transition-colors"
            >
              <PlusCircle className="w-4 h-4" />
              New Ticket
            </button>
          </div>
        )}

        {/* Navigation */}
        <nav className="flex-1 py-2 overflow-y-auto">
          {visibleMenuItems.map(item => {
            const isActive = currentView === item.id ||
              (item.id === 'tickets' && (currentView === 'ticket-detail' || currentView === 'ticket-create')) ||
              (item.id === 'assets' && currentView === 'asset-detail') ||
              (item.id === 'users' && currentView === 'user-detail') ||
              (item.id === 'kb' && currentView === 'kb-article');
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => navigateTo(item.id)}
                className={`w-full flex items-center gap-3 px-4 py-2.5 text-sm transition-colors relative group
                  ${isActive ? 'bg-slate-700/60 text-white border-r-2 border-blue-500' : 'text-slate-400 hover:text-white hover:bg-slate-800'}`}
                title={!sidebarOpen ? item.label : undefined}
              >
                <Icon className="w-5 h-5 flex-shrink-0" />
                {sidebarOpen && (
                  <>
                    <span className="flex-1 text-left">{item.label}</span>
                    {item.id === 'tickets' && openTickets > 0 && (
                      <span className="bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full min-w-[20px] text-center">
                        {openTickets}
                      </span>
                    )}
                  </>
                )}
                {!sidebarOpen && item.id === 'tickets' && openTickets > 0 && (
                  <span className="absolute top-1 right-1 w-2 h-2 bg-red-500 rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Submit Ticket (Public) */}
        {sidebarOpen && (
          <div className="p-3 border-t border-slate-700">
            <button
              onClick={() => navigateTo('submit-ticket')}
              className="w-full flex items-center gap-2 px-3 py-2 bg-slate-700 hover:bg-slate-600 rounded-lg text-xs text-slate-300 transition-colors"
            >
              <MessageSquare className="w-4 h-4" />
              Public Ticket Form
            </button>
          </div>
        )}

        {/* Auth / User */}
        {sidebarOpen && (
          <div className="p-3 border-t border-slate-700">
            {isAuthenticated && managedUser ? (
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gradient-to-br from-emerald-400 to-teal-500 rounded-full flex items-center justify-center text-sm font-bold">
                  {managedUser.first_name[0]}{managedUser.last_name[0]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium truncate">{managedUser.full_name}</p>
                  <p className="text-xs text-slate-400 truncate">{managedUser.title || managedUser.role}</p>
                </div>
                <button onClick={signOut} className="p-1.5 rounded-lg hover:bg-slate-700 text-slate-400 hover:text-white" title="Sign Out">
                  <LogOut className="w-4 h-4" />
                </button>
              </div>
            ) : (
              <button onClick={() => { setShowAuthModal(true); setAuthMode('login'); }}
                className="w-full flex items-center gap-2 px-3 py-2 bg-blue-600 hover:bg-blue-700 rounded-lg text-sm font-medium transition-colors">
                <LogIn className="w-4 h-4" /> Sign In
              </button>
            )}
          </div>
        )}
      </aside>

      {/* Auth Modal */}
      {showAuthModal && (
        <div className="fixed inset-0 bg-black/60 flex items-center justify-center z-[100]" onClick={() => setShowAuthModal(false)}>
          <div className="bg-white rounded-2xl p-6 w-full max-w-md mx-4 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-xl font-bold text-gray-900">{authMode === 'login' ? 'Sign In' : 'Create Account'}</h2>
                <p className="text-sm text-gray-500 mt-1">
                  {authMode === 'login' ? 'Welcome back to ServiceDesk' : 'Join ServiceDesk to submit and track tickets'}
                </p>
              </div>
              <button onClick={() => setShowAuthModal(false)} className="p-2 rounded-lg hover:bg-gray-100"><X className="w-5 h-5 text-gray-500" /></button>
            </div>

            <form onSubmit={handleAuth} className="space-y-4">
              {authMode === 'signup' && (
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
                    <input type="text" value={firstName} onChange={e => setFirstName(e.target.value)}
                      className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
                    <input type="text" value={lastName} onChange={e => setLastName(e.target.value)}
                      className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500" required />
                  </div>
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
                <input type="email" value={email} onChange={e => setEmail(e.target.value)}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="you@company.com" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Password</label>
                <input type="password" value={password} onChange={e => setPassword(e.target.value)}
                  className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Min 6 characters" minLength={6} required />
              </div>

              {authError && (
                <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                  <p className="text-sm text-red-700">{authError}</p>
                </div>
              )}

              <button type="submit" disabled={authLoading2}
                className="w-full px-4 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2 transition-colors">
                {authLoading2 ? <Loader2 className="w-4 h-4 animate-spin" /> : authMode === 'login' ? <LogIn className="w-4 h-4" /> : <UserPlus className="w-4 h-4" />}
                {authLoading2 ? 'Please wait...' : authMode === 'login' ? 'Sign In' : 'Create Account'}
              </button>
            </form>

            <div className="mt-4 text-center">
              {authMode === 'login' ? (
                <p className="text-sm text-gray-600">
                  Don't have an account?{' '}
                  <button onClick={() => { setAuthMode('signup'); setAuthError(''); }} className="text-blue-600 hover:text-blue-800 font-medium">Sign Up</button>
                </p>
              ) : (
                <p className="text-sm text-gray-600">
                  Already have an account?{' '}
                  <button onClick={() => { setAuthMode('login'); setAuthError(''); }} className="text-blue-600 hover:text-blue-800 font-medium">Sign In</button>
                </p>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Sidebar;
