import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import { ArrowLeft, Zap, Loader2, Sparkles, Send } from 'lucide-react';

const TicketCreateView: React.FC = () => {
  const { departments, users, assets, navigateTo, createTicket } = useAppContext();
  const [form, setForm] = useState({
    subject: '', description: '', priority: 'medium', category: '', department_id: '',
    requester_name: '', requester_email: '', asset_id: '', assigned_to: '',
  });
  const [aiAnalysis, setAiAnalysis] = useState<any>(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  const handleAiAnalyze = async () => {
    if (!form.subject || !form.description) return;
    setAnalyzing(true);
    try {
      const { data } = await supabase.functions.invoke('ai-assist', {
        body: { action: 'analyze_ticket', data: { subject: form.subject, description: form.description, requester_name: form.requester_name } }
      });
      if (data?.result) {
        try {
          const cleaned = data.result.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
          const parsed = JSON.parse(cleaned);
          setAiAnalysis(parsed);
          if (parsed.category) setForm(f => ({ ...f, category: parsed.category }));
          if (parsed.priority) setForm(f => ({ ...f, priority: parsed.priority }));
        } catch { setAiAnalysis({ summary: data.result }); }
      }
    } catch (err) { console.error(err); }
    setAnalyzing(false);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.subject || !form.description) return;
    setSubmitting(true);
    const ticket = await createTicket({
      ...form,
      source: 'web',
      status: 'open' as any,
      asset_id: form.asset_id || null,
      assigned_to: form.assigned_to || null,
      ai_suggestion: aiAnalysis ? JSON.stringify(aiAnalysis) : null,
    } as any);
    setSubmitting(false);
    if (ticket) navigateTo('ticket-detail', ticket.id);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <button onClick={() => navigateTo('tickets')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700">
        <ArrowLeft className="w-4 h-4" /> Back to Tickets
      </button>

      <div>
        <h1 className="text-2xl font-bold text-gray-900">Create New Ticket</h1>
        <p className="text-sm text-gray-500 mt-1">Submit a new service request or incident report</p>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-4">
            <h3 className="text-sm font-semibold text-gray-900">Ticket Details</h3>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Subject *</label>
              <input type="text" value={form.subject} onChange={e => setForm({...form, subject: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                placeholder="Brief description of the issue" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Description *</label>
              <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                rows={6} placeholder="Detailed description of the issue, steps to reproduce, etc." required />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
                <select value={form.priority} onChange={e => setForm({...form, priority: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option value="low">Low</option>
                  <option value="medium">Medium</option>
                  <option value="high">High</option>
                  <option value="critical">Critical</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
                <select value={form.category} onChange={e => setForm({...form, category: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option value="">Select category...</option>
                  {['Hardware', 'Software', 'Network', 'Email', 'Access', 'Security', 'Onboarding', 'Other'].map(c =>
                    <option key={c} value={c}>{c}</option>
                  )}
                </select>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
                <select value={form.department_id} onChange={e => setForm({...form, department_id: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option value="">Select department...</option>
                  {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Related Asset</label>
                <select value={form.asset_id} onChange={e => setForm({...form, asset_id: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                  <option value="">None</option>
                  {assets.map(a => <option key={a.id} value={a.id}>{a.asset_tag} - {a.name}</option>)}
                </select>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-4">
            <h3 className="text-sm font-semibold text-gray-900">Requester Information</h3>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                <input type="text" value={form.requester_name} onChange={e => setForm({...form, requester_name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="Full name" required />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                <input type="email" value={form.requester_email} onChange={e => setForm({...form, requester_email: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="email@company.com" required />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Assign To</label>
              <select value={form.assigned_to} onChange={e => setForm({...form, assigned_to: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option value="">Auto-assign</option>
                {users.filter(u => u.role === 'technician' || u.role === 'admin').map(u =>
                  <option key={u.id} value={u.id}>{u.full_name} - {u.title}</option>
                )}
              </select>
            </div>
          </div>

          <div className="flex gap-3">
            <button type="button" onClick={() => navigateTo('tickets')} className="px-6 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50">Cancel</button>
            <button type="submit" disabled={submitting} className="flex-1 px-6 py-2.5 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2">
              {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
              {submitting ? 'Creating...' : 'Create Ticket'}
            </button>
          </div>
        </div>

        {/* AI Sidebar */}
        <div className="space-y-6">
          <div className="bg-gradient-to-br from-indigo-50 to-purple-50 rounded-xl border border-indigo-200 p-6">
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-5 h-5 text-indigo-600" />
              <h3 className="text-sm font-semibold text-indigo-900">AI Analysis</h3>
            </div>
            <p className="text-xs text-indigo-700 mb-4">Let AI analyze the ticket to suggest category, priority, and resolution.</p>
            <button type="button" onClick={handleAiAnalyze} disabled={analyzing || !form.subject || !form.description}
              className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg text-sm font-medium hover:bg-indigo-700 disabled:opacity-50 flex items-center justify-center gap-2">
              {analyzing ? <Loader2 className="w-4 h-4 animate-spin" /> : <Zap className="w-4 h-4" />}
              {analyzing ? 'Analyzing...' : 'Analyze Ticket'}
            </button>

            {aiAnalysis && (
              <div className="mt-4 space-y-3">
                {aiAnalysis.summary && (
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs font-medium text-gray-700 mb-1">Summary</p>
                    <p className="text-xs text-gray-600">{aiAnalysis.summary}</p>
                  </div>
                )}
                {aiAnalysis.category && (
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs font-medium text-gray-700 mb-1">Suggested Category</p>
                    <p className="text-sm font-medium text-indigo-700">{aiAnalysis.category}</p>
                  </div>
                )}
                {aiAnalysis.priority && (
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs font-medium text-gray-700 mb-1">Suggested Priority</p>
                    <p className={`text-sm font-medium ${aiAnalysis.priority === 'critical' ? 'text-red-700' : aiAnalysis.priority === 'high' ? 'text-orange-700' : 'text-yellow-700'}`}>
                      {aiAnalysis.priority}
                    </p>
                  </div>
                )}
                {aiAnalysis.suggested_resolution && (
                  <div className="p-3 bg-white rounded-lg">
                    <p className="text-xs font-medium text-gray-700 mb-1">Suggested Resolution</p>
                    <p className="text-xs text-gray-600">{aiAnalysis.suggested_resolution}</p>
                  </div>
                )}
                {aiAnalysis.needs_more_info && aiAnalysis.info_questions?.length > 0 && (
                  <div className="p-3 bg-amber-50 border border-amber-200 rounded-lg">
                    <p className="text-xs font-medium text-amber-800 mb-1">More Info Needed</p>
                    <ul className="text-xs text-amber-700 space-y-1">
                      {aiAnalysis.info_questions.map((q: string, i: number) => <li key={i}>• {q}</li>)}
                    </ul>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </form>
    </div>
  );
};

export default TicketCreateView;
