import React, { useState, useEffect } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import {
  ArrowLeft, Clock, User, Monitor, Tag, Send, Sparkles, Loader2,
  AlertTriangle, CheckCircle2, Circle, Pause, MessageSquare, BookOpen
} from 'lucide-react';
import type { TicketComment } from '@/lib/types';

const TicketDetailView: React.FC = () => {
  const { selectedId, tickets, users, departments, assets, kbArticles, navigateTo, updateTicket } = useAppContext();
  const ticket = tickets.find(t => t.id === selectedId);
  const [comments, setComments] = useState<TicketComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [isInternal, setIsInternal] = useState(false);
  const [aiSuggesting, setAiSuggesting] = useState(false);
  const [aiSuggestion, setAiSuggestion] = useState('');
  const [editStatus, setEditStatus] = useState('');
  const [editAssigned, setEditAssigned] = useState('');
  const [resolution, setResolution] = useState('');

  useEffect(() => {
    if (selectedId) {
      supabase.from('ticket_comments').select('*').eq('ticket_id', selectedId).order('created_at').then(({ data }) => {
        if (data) setComments(data);
      });
    }
  }, [selectedId]);

  useEffect(() => {
    if (ticket) {
      setEditStatus(ticket.status);
      setEditAssigned(ticket.assigned_to || '');
      setResolution(ticket.resolution || '');
    }
  }, [ticket]);

  if (!ticket) return <div className="flex items-center justify-center h-64"><p className="text-gray-500">Ticket not found</p></div>;

  const dept = departments.find(d => d.id === ticket.department_id);
  const assignedUser = ticket.assigned_to ? users.find(u => u.id === ticket.assigned_to) : null;
  const linkedAsset = ticket.asset_id ? assets.find(a => a.id === ticket.asset_id) : null;

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    await supabase.from('ticket_comments').insert({
      ticket_id: ticket.id, content: newComment, author_name: 'Sarah Chen', is_internal: isInternal, is_ai: false,
    });
    setComments(prev => [...prev, { id: Date.now().toString(), ticket_id: ticket.id, author_id: null, author_name: 'Sarah Chen', content: newComment, is_internal: isInternal, is_ai: false, created_at: new Date().toISOString() }]);
    setNewComment('');
  };

  const handleAiSuggest = async () => {
    setAiSuggesting(true);
    try {
      const { data } = await supabase.functions.invoke('ai-assist', {
        body: {
          action: 'suggest_resolution',
          data: { subject: ticket.subject, description: ticket.description, kb_articles: kbArticles.slice(0, 5) }
        }
      });
      if (data?.result) {
        setAiSuggestion(data.result);
        await supabase.from('ticket_comments').insert({
          ticket_id: ticket.id, content: data.result, author_name: 'AI Assistant', is_internal: true, is_ai: true,
        });
        setComments(prev => [...prev, { id: Date.now().toString(), ticket_id: ticket.id, author_id: null, author_name: 'AI Assistant', content: data.result, is_internal: true, is_ai: true, created_at: new Date().toISOString() }]);
      }
    } catch (err) { console.error(err); }
    setAiSuggesting(false);
  };

  const handleSaveChanges = async () => {
    const updates: any = { status: editStatus, assigned_to: editAssigned || null };
    if (editStatus === 'resolved') { updates.resolution = resolution; updates.resolved_at = new Date().toISOString(); }
    if (editStatus === 'closed') { updates.closed_at = new Date().toISOString(); }
    await updateTicket(ticket.id, updates);
  };

  const priorityColor = (p: string) => {
    switch(p) { case 'critical': return 'bg-red-100 text-red-700 border-red-200'; case 'high': return 'bg-orange-100 text-orange-700 border-orange-200'; case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200'; default: return 'bg-green-100 text-green-700 border-green-200'; }
  };

  const statusIcon = (s: string) => {
    switch(s) { case 'open': return <Circle className="w-4 h-4 text-blue-500" />; case 'in_progress': return <Clock className="w-4 h-4 text-amber-500" />; case 'pending': return <Pause className="w-4 h-4 text-purple-500" />; case 'resolved': return <CheckCircle2 className="w-4 h-4 text-green-500" />; default: return <CheckCircle2 className="w-4 h-4 text-gray-500" />; }
  };

  return (
    <div className="space-y-6">
      <button onClick={() => navigateTo('tickets')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700">
        <ArrowLeft className="w-4 h-4" /> Back to Tickets
      </button>

      {/* Header */}
      <div className="bg-white rounded-xl border border-gray-200 p-6">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-3 mb-2">
              <span className="text-sm font-mono text-gray-500">{ticket.ticket_number}</span>
              <span className={`px-2 py-0.5 rounded-full text-xs font-medium border ${priorityColor(ticket.priority)}`}>{ticket.priority}</span>
              <span className="px-2 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-600">{ticket.source}</span>
            </div>
            <h1 className="text-xl font-bold text-gray-900">{ticket.subject}</h1>
            <p className="text-sm text-gray-500 mt-1">Submitted by {ticket.requester_name} ({ticket.requester_email}) · {new Date(ticket.created_at).toLocaleString()}</p>
          </div>
          <div className="flex items-center gap-2">
            {statusIcon(ticket.status)}
            <span className="text-sm font-medium text-gray-700 capitalize">{ticket.status.replace('_', ' ')}</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-3">Description</h3>
            <p className="text-sm text-gray-700 whitespace-pre-wrap">{ticket.description}</p>
          </div>

          {/* AI Suggestion */}
          <div className="bg-gradient-to-r from-indigo-50 to-purple-50 rounded-xl border border-indigo-200 p-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-indigo-600" />
                <h3 className="text-sm font-semibold text-indigo-900">AI Resolution Assistant</h3>
              </div>
              <button onClick={handleAiSuggest} disabled={aiSuggesting}
                className="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-xs font-medium hover:bg-indigo-700 disabled:opacity-50 flex items-center gap-1">
                {aiSuggesting ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                {aiSuggesting ? 'Analyzing...' : 'Get AI Suggestion'}
              </button>
            </div>
            {aiSuggestion && <p className="text-sm text-indigo-800 whitespace-pre-wrap mt-2">{aiSuggestion}</p>}
          </div>

          {/* Comments */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Comments ({comments.length})</h3>
            <div className="space-y-4 mb-4">
              {comments.map(c => (
                <div key={c.id} className={`p-3 rounded-lg ${c.is_ai ? 'bg-indigo-50 border border-indigo-100' : c.is_internal ? 'bg-amber-50 border border-amber-100' : 'bg-gray-50'}`}>
                  <div className="flex items-center gap-2 mb-1">
                    {c.is_ai ? <Sparkles className="w-3 h-3 text-indigo-600" /> : <User className="w-3 h-3 text-gray-400" />}
                    <span className="text-xs font-medium text-gray-900">{c.author_name}</span>
                    {c.is_internal && <span className="text-xs bg-amber-200 text-amber-800 px-1.5 py-0.5 rounded">Internal</span>}
                    {c.is_ai && <span className="text-xs bg-indigo-200 text-indigo-800 px-1.5 py-0.5 rounded">AI</span>}
                    <span className="text-xs text-gray-500 ml-auto">{new Date(c.created_at).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{c.content}</p>
                </div>
              ))}
              {comments.length === 0 && <p className="text-sm text-gray-500">No comments yet.</p>}
            </div>
            <div className="border-t border-gray-200 pt-4">
              <textarea value={newComment} onChange={e => setNewComment(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm mb-2" rows={3} placeholder="Add a comment..." />
              <div className="flex items-center justify-between">
                <label className="flex items-center gap-2 text-sm text-gray-600">
                  <input type="checkbox" checked={isInternal} onChange={e => setIsInternal(e.target.checked)} className="rounded" />
                  Internal note
                </label>
                <button onClick={handleAddComment} disabled={!newComment.trim()}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center gap-2">
                  <Send className="w-4 h-4" /> Add Comment
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Status Management */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-4">
            <h3 className="text-sm font-semibold text-gray-900">Manage Ticket</h3>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Status</label>
              <select value={editStatus} onChange={e => setEditStatus(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option value="open">Open</option>
                <option value="in_progress">In Progress</option>
                <option value="pending">Pending</option>
                <option value="resolved">Resolved</option>
                <option value="closed">Closed</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-medium text-gray-700 mb-1">Assigned To</label>
              <select value={editAssigned} onChange={e => setEditAssigned(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm">
                <option value="">Unassigned</option>
                {users.filter(u => u.role === 'technician' || u.role === 'admin').map(u =>
                  <option key={u.id} value={u.id}>{u.full_name}</option>
                )}
              </select>
            </div>
            {editStatus === 'resolved' && (
              <div>
                <label className="block text-xs font-medium text-gray-700 mb-1">Resolution</label>
                <textarea value={resolution} onChange={e => setResolution(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" rows={3} placeholder="Describe the resolution..." />
              </div>
            )}
            <button onClick={handleSaveChanges} className="w-full px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
              Save Changes
            </button>
          </div>

          {/* Details */}
          <div className="bg-white rounded-xl border border-gray-200 p-6 space-y-3">
            <h3 className="text-sm font-semibold text-gray-900">Details</h3>
            {[
              { label: 'Category', value: ticket.category || '-' },
              { label: 'Department', value: dept?.name || '-' },
              { label: 'Source', value: ticket.source },
              { label: 'Created', value: new Date(ticket.created_at).toLocaleDateString() },
              { label: 'Updated', value: new Date(ticket.updated_at).toLocaleDateString() },
            ].map(item => (
              <div key={item.label} className="flex justify-between">
                <span className="text-xs text-gray-500">{item.label}</span>
                <span className="text-xs font-medium text-gray-900">{item.value}</span>
              </div>
            ))}
          </div>

          {/* Linked Asset */}
          {linkedAsset && (
            <div className="bg-white rounded-xl border border-gray-200 p-6">
              <h3 className="text-sm font-semibold text-gray-900 mb-3">Linked Asset</h3>
              <button onClick={() => navigateTo('asset-detail', linkedAsset.id)} className="w-full flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 text-left">
                <Monitor className="w-5 h-5 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-gray-900">{linkedAsset.name}</p>
                  <p className="text-xs text-gray-500">{linkedAsset.asset_tag}</p>
                </div>
              </button>
            </div>
          )}

          {/* Relevant KB */}
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <div className="flex items-center gap-2 mb-3">
              <BookOpen className="w-4 h-4 text-gray-400" />
              <h3 className="text-sm font-semibold text-gray-900">Related KB Articles</h3>
            </div>
            {kbArticles.filter(a => {
              const terms = ticket.subject.toLowerCase().split(' ');
              return terms.some(t => a.title.toLowerCase().includes(t) || a.tags?.some(tag => tag.includes(t)));
            }).slice(0, 3).map(article => (
              <button key={article.id} onClick={() => navigateTo('kb-article', article.id)}
                className="w-full text-left p-2 rounded-lg hover:bg-gray-50 mb-1">
                <p className="text-sm text-blue-600 hover:text-blue-800">{article.title}</p>
                <p className="text-xs text-gray-500">{article.category}</p>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TicketDetailView;
