import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { Shield, Send, Loader2, CheckCircle2, ArrowLeft } from 'lucide-react';

const PublicTicketForm: React.FC = () => {
  const { departments, createTicket, navigateTo } = useAppContext();
  const [form, setForm] = useState({ subject: '', description: '', priority: 'medium', category: '', department_id: '', requester_name: '', requester_email: '' });
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [ticketNumber, setTicketNumber] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    const ticket = await createTicket({ ...form, source: 'web', status: 'open' as any } as any);
    setSubmitting(false);
    if (ticket) { setSubmitted(true); setTicketNumber(ticket.ticket_number); }
  };

  if (submitted) {
    return (
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-2xl border border-gray-200 p-8 text-center">
          <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <CheckCircle2 className="w-8 h-8 text-green-600" />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Ticket Submitted!</h2>
          <p className="text-gray-600 mb-4">Your ticket <span className="font-mono font-bold text-blue-600">{ticketNumber}</span> has been created successfully.</p>
          <p className="text-sm text-gray-500 mb-6">You will receive email updates at {form.requester_email}</p>
          <div className="flex gap-3 justify-center">
            <button onClick={() => { setSubmitted(false); setForm({ subject: '', description: '', priority: 'medium', category: '', department_id: '', requester_name: '', requester_email: '' }); }}
              className="px-6 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">Submit Another</button>
            <button onClick={() => navigateTo('dashboard')} className="px-6 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">Go to Dashboard</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto">
      <button onClick={() => navigateTo('dashboard')} className="flex items-center gap-2 text-sm text-gray-500 hover:text-gray-700 mb-6">
        <ArrowLeft className="w-4 h-4" /> Back to Dashboard
      </button>

      <div className="text-center mb-8">
        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center mx-auto mb-4">
          <Shield className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-2xl font-bold text-gray-900">Submit a Service Request</h1>
        <p className="text-sm text-gray-500 mt-2">Fill out the form below and our team will get back to you promptly.</p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-2xl border border-gray-200 p-6 space-y-5">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Your Name *</label>
            <input type="text" value={form.requester_name} onChange={e => setForm({...form, requester_name: e.target.value})}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Email Address *</label>
            <input type="email" value={form.requester_email} onChange={e => setForm({...form, requester_email: e.target.value})}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" required />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Subject *</label>
          <input type="text" value={form.subject} onChange={e => setForm({...form, subject: e.target.value})}
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" placeholder="Brief description of your issue" required />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Description *</label>
          <textarea value={form.description} onChange={e => setForm({...form, description: e.target.value})}
            className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500" rows={5} placeholder="Please provide as much detail as possible..." required />
        </div>
        <div className="grid grid-cols-3 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Category</label>
            <select value={form.category} onChange={e => setForm({...form, category: e.target.value})}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm">
              <option value="">Select...</option>
              {['Hardware', 'Software', 'Network', 'Email', 'Access', 'Security', 'Other'].map(c => <option key={c}>{c}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Priority</label>
            <select value={form.priority} onChange={e => setForm({...form, priority: e.target.value})}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm">
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
              <option value="critical">Critical</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Department</label>
            <select value={form.department_id} onChange={e => setForm({...form, department_id: e.target.value})}
              className="w-full px-3 py-2.5 border border-gray-300 rounded-lg text-sm">
              <option value="">Select...</option>
              {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
            </select>
          </div>
        </div>
        <button type="submit" disabled={submitting}
          className="w-full px-6 py-3 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2">
          {submitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          {submitting ? 'Submitting...' : 'Submit Request'}
        </button>
      </form>
    </div>
  );
};

export default PublicTicketForm;
