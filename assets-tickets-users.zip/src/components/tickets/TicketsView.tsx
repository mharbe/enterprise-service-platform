import React, { useState, useMemo } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import {
  Search, Filter, Plus, Clock, AlertTriangle, CheckCircle2, Circle,
  Pause, X, ArrowUpDown, Mail, Globe, Phone, MessageSquare, Zap
} from 'lucide-react';

const TicketsView: React.FC = () => {
  const { tickets, departments, users, navigateTo, updateTicket } = useAppContext();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [deptFilter, setDeptFilter] = useState('all');
  const [sortBy, setSortBy] = useState('created_at');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('desc');

  const filtered = useMemo(() => {
    let result = tickets.filter(t => {
      const matchSearch = search === '' ||
        t.subject.toLowerCase().includes(search.toLowerCase()) ||
        t.ticket_number.toLowerCase().includes(search.toLowerCase()) ||
        t.requester_name?.toLowerCase().includes(search.toLowerCase()) ||
        t.requester_email?.toLowerCase().includes(search.toLowerCase());
      const matchStatus = statusFilter === 'all' || t.status === statusFilter;
      const matchPriority = priorityFilter === 'all' || t.priority === priorityFilter;
      const matchDept = deptFilter === 'all' || t.department_id === deptFilter;
      return matchSearch && matchStatus && matchPriority && matchDept;
    });
    result.sort((a, b) => {
      const aVal = (a as any)[sortBy] || '';
      const bVal = (b as any)[sortBy] || '';
      if (sortBy === 'created_at') return sortDir === 'desc' ? new Date(bVal).getTime() - new Date(aVal).getTime() : new Date(aVal).getTime() - new Date(bVal).getTime();
      return sortDir === 'asc' ? String(aVal).localeCompare(String(bVal)) : String(bVal).localeCompare(String(aVal));
    });
    return result;
  }, [tickets, search, statusFilter, priorityFilter, deptFilter, sortBy, sortDir]);

  const statusCounts = {
    open: tickets.filter(t => t.status === 'open').length,
    in_progress: tickets.filter(t => t.status === 'in_progress').length,
    pending: tickets.filter(t => t.status === 'pending').length,
    resolved: tickets.filter(t => t.status === 'resolved').length,
    closed: tickets.filter(t => t.status === 'closed').length,
  };

  const priorityIcon = (p: string) => {
    switch(p) {
      case 'critical': return <AlertTriangle className="w-3.5 h-3.5 text-red-600" />;
      case 'high': return <AlertTriangle className="w-3.5 h-3.5 text-orange-500" />;
      case 'medium': return <Circle className="w-3.5 h-3.5 text-yellow-500" />;
      default: return <Circle className="w-3.5 h-3.5 text-green-500" />;
    }
  };

  const statusBadge = (s: string) => {
    const config: Record<string, { bg: string; text: string; icon: React.ElementType }> = {
      open: { bg: 'bg-blue-100', text: 'text-blue-700', icon: Circle },
      in_progress: { bg: 'bg-amber-100', text: 'text-amber-700', icon: Clock },
      pending: { bg: 'bg-purple-100', text: 'text-purple-700', icon: Pause },
      resolved: { bg: 'bg-green-100', text: 'text-green-700', icon: CheckCircle2 },
      closed: { bg: 'bg-gray-100', text: 'text-gray-600', icon: CheckCircle2 },
    };
    const c = config[s] || config.open;
    const Icon = c.icon;
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium ${c.bg} ${c.text}`}>
        <Icon className="w-3 h-3" />
        {s.replace('_', ' ')}
      </span>
    );
  };

  const sourceIcon = (s: string) => {
    switch(s) {
      case 'email': return <Mail className="w-3.5 h-3.5 text-gray-400" />;
      case 'phone': return <Phone className="w-3.5 h-3.5 text-gray-400" />;
      case 'chat': return <MessageSquare className="w-3.5 h-3.5 text-gray-400" />;
      case 'ai': return <Zap className="w-3.5 h-3.5 text-gray-400" />;
      default: return <Globe className="w-3.5 h-3.5 text-gray-400" />;
    }
  };

  const toggleSort = (field: string) => {
    if (sortBy === field) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortBy(field); setSortDir('desc'); }
  };

  const getDeptName = (id: string) => departments.find(d => d.id === id)?.name || '-';
  const getUserName = (id: string | null) => { if (!id) return 'Unassigned'; const u = users.find(u => u.id === id); return u ? u.full_name : 'Unassigned'; };

  const timeAgo = (date: string) => {
    const diff = Date.now() - new Date(date).getTime();
    const hours = Math.floor(diff / 3600000);
    if (hours < 1) return 'Just now';
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Tickets</h1>
          <p className="text-sm text-gray-500 mt-1">{tickets.length} total tickets</p>
        </div>
        <button onClick={() => navigateTo('ticket-create')} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center gap-2">
          <Plus className="w-4 h-4" /> New Ticket
        </button>
      </div>

      {/* Status Tabs */}
      <div className="flex gap-2 flex-wrap">
        {[
          { key: 'all', label: 'All', count: tickets.length },
          { key: 'open', label: 'Open', count: statusCounts.open },
          { key: 'in_progress', label: 'In Progress', count: statusCounts.in_progress },
          { key: 'pending', label: 'Pending', count: statusCounts.pending },
          { key: 'resolved', label: 'Resolved', count: statusCounts.resolved },
        ].map(tab => (
          <button key={tab.key} onClick={() => setStatusFilter(tab.key)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors flex items-center gap-2
              ${statusFilter === tab.key ? 'bg-blue-600 text-white' : 'bg-white text-gray-700 border border-gray-200 hover:bg-gray-50'}`}>
            {tab.label}
            <span className={`px-1.5 py-0.5 rounded-full text-xs ${statusFilter === tab.key ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600'}`}>
              {tab.count}
            </span>
          </button>
        ))}
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-200 p-4">
        <div className="flex flex-wrap gap-3">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input type="text" placeholder="Search tickets..." value={search} onChange={e => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500" />
          </div>
          <select value={priorityFilter} onChange={e => setPriorityFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white">
            <option value="all">All Priorities</option>
            <option value="critical">Critical</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>
          <select value={deptFilter} onChange={e => setDeptFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-lg text-sm bg-white">
            <option value="all">All Departments</option>
            {departments.map(d => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
        </div>
      </div>

      {/* Tickets List */}
      <div className="bg-white rounded-xl border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="bg-gray-50 border-b border-gray-200">
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase w-8"></th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase cursor-pointer" onClick={() => toggleSort('ticket_number')}>
                  <div className="flex items-center gap-1">Ticket {sortBy === 'ticket_number' && <ArrowUpDown className="w-3 h-3" />}</div>
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase cursor-pointer" onClick={() => toggleSort('subject')}>Subject</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Status</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Requester</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Assigned</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Department</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase">Source</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-500 uppercase cursor-pointer" onClick={() => toggleSort('created_at')}>
                  <div className="flex items-center gap-1">Created {sortBy === 'created_at' && <ArrowUpDown className="w-3 h-3" />}</div>
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map(ticket => (
                <tr key={ticket.id} className="hover:bg-gray-50 transition-colors cursor-pointer" onClick={() => navigateTo('ticket-detail', ticket.id)}>
                  <td className="px-4 py-3">{priorityIcon(ticket.priority)}</td>
                  <td className="px-4 py-3 text-sm font-mono text-blue-600 font-medium">{ticket.ticket_number}</td>
                  <td className="px-4 py-3">
                    <p className="text-sm font-medium text-gray-900 max-w-[300px] truncate">{ticket.subject}</p>
                    {ticket.category && <p className="text-xs text-gray-500">{ticket.category}</p>}
                  </td>
                  <td className="px-4 py-3">{statusBadge(ticket.status)}</td>
                  <td className="px-4 py-3">
                    <p className="text-sm text-gray-900">{ticket.requester_name}</p>
                    <p className="text-xs text-gray-500">{ticket.requester_email}</p>
                  </td>
                  <td className="px-4 py-3 text-sm text-gray-700">{getUserName(ticket.assigned_to)}</td>
                  <td className="px-4 py-3 text-sm text-gray-700">{getDeptName(ticket.department_id)}</td>
                  <td className="px-4 py-3">{sourceIcon(ticket.source)}</td>
                  <td className="px-4 py-3 text-sm text-gray-500">{timeAgo(ticket.created_at)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="px-4 py-3 bg-gray-50 border-t border-gray-200 text-sm text-gray-500">
          Showing {filtered.length} of {tickets.length} tickets
        </div>
      </div>
    </div>
  );
};

export default TicketsView;
