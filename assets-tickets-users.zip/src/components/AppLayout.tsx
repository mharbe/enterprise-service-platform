import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { useAuth } from '@/contexts/AuthContext';
import { useIsMobile } from '@/hooks/use-mobile';
import Sidebar from './Sidebar';
import DashboardView from './dashboard/DashboardView';
import AssetsView from './assets/AssetsView';
import AssetDetailView from './assets/AssetDetailView';
import TicketsView from './tickets/TicketsView';
import TicketCreateView from './tickets/TicketCreateView';
import TicketDetailView from './tickets/TicketDetailView';
import PublicTicketForm from './tickets/PublicTicketForm';
import UsersView from './users/UsersView';
import UserDetailView from './users/UserDetailView';
import KnowledgeBaseView from './kb/KnowledgeBaseView';
import IntegrationsView from './integrations/IntegrationsView';
import SettingsView from './settings/SettingsView';
import ChatAssist from './chat/ChatAssist';
import { Loader2, Menu, Bell, ShieldAlert, Lock } from 'lucide-react';

const PermissionDenied: React.FC = () => (
  <div className="flex flex-col items-center justify-center h-64 text-center">
    <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
      <Lock className="w-8 h-8 text-red-500" />
    </div>
    <h2 className="text-lg font-semibold text-gray-900 mb-1">Access Denied</h2>
    <p className="text-sm text-gray-500 max-w-md">You don't have permission to access this section. Contact your administrator to request access.</p>
  </div>
);

const AppLayout: React.FC = () => {
  const { sidebarOpen, toggleSidebar, currentView, loading, navigateTo, tickets } = useAppContext();
  const { isAuthenticated, can, loading: authLoading } = useAuth();
  const isMobile = useIsMobile();

  const viewLabel = (view: string) => {
    const labels: Record<string, string> = {
      dashboard: 'Dashboard', assets: 'Assets', 'asset-detail': 'Asset Details',
      tickets: 'Tickets', 'ticket-create': 'New Ticket', 'ticket-detail': 'Ticket Details',
      'submit-ticket': 'Submit Request', users: 'Users', 'user-detail': 'User Profile',
      kb: 'Knowledge Base', 'kb-article': 'KB Article', integrations: 'Integrations', settings: 'Settings',
    };
    return labels[view] || view;
  };

  const renderView = () => {
    // Public views - always accessible
    if (currentView === 'submit-ticket') return <PublicTicketForm />;
    if (currentView === 'dashboard') return <DashboardView />;
    if (currentView === 'kb' || currentView === 'kb-article') return <KnowledgeBaseView />;

    // Protected views - require auth + permission
    if (!isAuthenticated) return <PermissionDenied />;

    const viewPermissionMap: Record<string, [string, string]> = {
      assets: ['assets', 'view'],
      'asset-detail': ['assets', 'view'],
      tickets: ['tickets', 'view'],
      'ticket-create': ['tickets', 'create'],
      'ticket-detail': ['tickets', 'view'],
      users: ['users', 'view'],
      'user-detail': ['users', 'view'],
      integrations: ['integrations', 'view'],
      settings: ['settings', 'view'],
    };

    const perm = viewPermissionMap[currentView];
    if (perm && !can(perm[0], perm[1])) return <PermissionDenied />;

    switch (currentView) {
      case 'assets': return <AssetsView />;
      case 'asset-detail': return <AssetDetailView />;
      case 'tickets': return <TicketsView />;
      case 'ticket-create': return <TicketCreateView />;
      case 'ticket-detail': return <TicketDetailView />;
      case 'users': return <UsersView />;
      case 'user-detail': return <UserDetailView />;
      case 'integrations': return <IntegrationsView />;
      case 'settings': return <SettingsView />;
      default: return <DashboardView />;
    }
  };

  if (loading || authLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <Loader2 className="w-8 h-8 text-blue-600 animate-spin mx-auto mb-4" />
          <p className="text-sm text-gray-500">Loading ServiceDesk...</p>
        </div>
      </div>
    );
  }

  const criticalCount = tickets.filter(t => t.priority === 'critical' && t.status !== 'resolved' && t.status !== 'closed').length;

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {(!isMobile || sidebarOpen) && (
        <>
          {isMobile && sidebarOpen && (
            <div className="fixed inset-0 bg-black/50 z-40" onClick={toggleSidebar} />
          )}
          <div className={isMobile ? 'fixed left-0 top-0 z-50' : ''}>
            <Sidebar />
          </div>
        </>
      )}

      <main className="flex-1 overflow-y-auto">
        <div className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-gray-200 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {isMobile && (
              <button onClick={toggleSidebar} className="p-2 rounded-lg hover:bg-gray-100">
                <Menu className="w-5 h-5 text-gray-600" />
              </button>
            )}
            <nav className="flex items-center gap-1.5 text-sm text-gray-500">
              <button onClick={() => navigateTo('dashboard')} className="hover:text-gray-700 transition-colors">ServiceDesk</button>
              <span className="text-gray-300">/</span>
              <span className="text-gray-900 font-medium">{viewLabel(currentView)}</span>
            </nav>
          </div>
          <div className="flex items-center gap-3">
            {criticalCount > 0 && isAuthenticated && (
              <button onClick={() => navigateTo('tickets')} className="flex items-center gap-1.5 px-3 py-1.5 bg-red-50 border border-red-200 rounded-lg text-xs font-medium text-red-700 hover:bg-red-100 transition-colors">
                <Bell className="w-3.5 h-3.5" />
                {criticalCount} Critical
              </button>
            )}
            {!isAuthenticated && (
              <span className="flex items-center gap-1.5 text-xs text-amber-700 bg-amber-50 border border-amber-200 px-3 py-1.5 rounded-lg">
                <ShieldAlert className="w-3.5 h-3.5" /> Sign in for full access
              </span>
            )}
            <div className="text-xs text-gray-500 hidden md:block">
              {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
            </div>
          </div>
        </div>

        <div className="p-6">
          {renderView()}
        </div>
      </main>

      <ChatAssist />
    </div>
  );
};

export default AppLayout;
