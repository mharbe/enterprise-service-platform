import React from 'react';
import { useAppContext } from '@/contexts/AppContext';
import {
  Ticket, Monitor, Users, AlertTriangle, Clock, CheckCircle2, TrendingUp,
  ArrowUpRight, ArrowDownRight, Package, ShieldAlert, BookOpen, Zap
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts';

const DashboardView: React.FC = () => {
  const { tickets, assets, users, kbArticles, navigateTo } = useAppContext();

  const openTickets = tickets.filter(t => t.status === 'open').length;
  const inProgressTickets = tickets.filter(t => t.status === 'in_progress').length;
  const criticalTickets = tickets.filter(t => t.priority === 'critical' && t.status !== 'resolved' && t.status !== 'closed').length;
  const resolvedTickets = tickets.filter(t => t.status === 'resolved' || t.status === 'closed').length;

  const totalAssets = assets.length;
  const inUseAssets = assets.filter(a => a.status === 'in_use' || a.status === 'assigned').length;
  const availableAssets = assets.filter(a => a.status === 'available' || a.status === 'in_stock').length;
  const lostStolen = assets.filter(a => a.status === 'lost' || a.status === 'stolen').length;
  const unavailableAssets = assets.filter(a => a.status === 'unavailable').length;

  const assetCategories = assets.reduce((acc, a) => {
    acc[a.category] = (acc[a.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const categoryData = Object.entries(assetCategories).map(([name, value]) => ({ name, value }));
  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#6366F1', '#14B8A6'];

  const statusData = [
    { name: 'In Use', count: inUseAssets, color: '#3B82F6' },
    { name: 'Available', count: availableAssets, color: '#10B981' },
    { name: 'Lost/Stolen', count: lostStolen, color: '#EF4444' },
    { name: 'Unavailable', count: unavailableAssets, color: '#F59E0B' },
  ];

  const ticketTrend = [
    { day: 'Mon', tickets: 3 }, { day: 'Tue', tickets: 5 }, { day: 'Wed', tickets: 2 },
    { day: 'Thu', tickets: 7 }, { day: 'Fri', tickets: 4 }, { day: 'Sat', tickets: 1 }, { day: 'Sun', tickets: 0 },
  ];

  const recentTickets = tickets.slice(0, 6);

  const metricCards = [
    { label: 'Open Tickets', value: openTickets, icon: Ticket, color: 'bg-blue-500', trend: '+12%', trendUp: true, onClick: () => navigateTo('tickets') },
    { label: 'In Progress', value: inProgressTickets, icon: Clock, color: 'bg-amber-500', trend: '-3%', trendUp: false, onClick: () => navigateTo('tickets') },
    { label: 'Critical Issues', value: criticalTickets, icon: AlertTriangle, color: 'bg-red-500', trend: criticalTickets > 0 ? 'Action Required' : 'None', trendUp: false, onClick: () => navigateTo('tickets') },
    { label: 'Total Assets', value: totalAssets, icon: Monitor, color: 'bg-indigo-500', trend: `${availableAssets} available`, trendUp: true, onClick: () => navigateTo('assets') },
    { label: 'Active Users', value: users.filter(u => u.status === 'active').length, icon: Users, color: 'bg-emerald-500', trend: `${users.length} total`, trendUp: true, onClick: () => navigateTo('users') },
    { label: 'KB Articles', value: kbArticles.length, icon: BookOpen, color: 'bg-purple-500', trend: `${kbArticles.reduce((s, a) => s + a.views, 0)} views`, trendUp: true, onClick: () => navigateTo('kb') },
  ];

  const priorityColor = (p: string) => {
    switch(p) {
      case 'critical': return 'bg-red-100 text-red-700 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-700 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-700 border-yellow-200';
      default: return 'bg-green-100 text-green-700 border-green-200';
    }
  };

  const statusColor = (s: string) => {
    switch(s) {
      case 'open': return 'bg-blue-100 text-blue-700';
      case 'in_progress': return 'bg-amber-100 text-amber-700';
      case 'pending': return 'bg-purple-100 text-purple-700';
      case 'resolved': return 'bg-green-100 text-green-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-sm text-gray-500 mt-1">Welcome back, Sarah. Here's your service overview.</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => navigateTo('ticket-create')} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 transition-colors flex items-center gap-2">
            <Zap className="w-4 h-4" /> New Ticket
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
        {metricCards.map((card, i) => {
          const Icon = card.icon;
          return (
            <button key={i} onClick={card.onClick} className="bg-white rounded-xl border border-gray-200 p-4 hover:shadow-lg transition-all hover:border-gray-300 text-left group">
              <div className="flex items-center justify-between mb-3">
                <div className={`${card.color} p-2 rounded-lg`}>
                  <Icon className="w-4 h-4 text-white" />
                </div>
                <ArrowUpRight className="w-4 h-4 text-gray-400 group-hover:text-blue-500 transition-colors" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{card.value}</p>
              <p className="text-xs text-gray-500 mt-1">{card.label}</p>
              <p className={`text-xs mt-1 ${card.trendUp ? 'text-emerald-600' : 'text-gray-500'}`}>{card.trend}</p>
            </button>
          );
        })}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Ticket Trend */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 lg:col-span-2">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">Ticket Volume (This Week)</h3>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={ticketTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} />
              <YAxis tick={{ fontSize: 12 }} />
              <Tooltip />
              <Bar dataKey="tickets" fill="#3B82F6" radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Asset Distribution */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <h3 className="text-sm font-semibold text-gray-900 mb-4">Asset Categories</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={categoryData} cx="50%" cy="50%" innerRadius={40} outerRadius={70} dataKey="value" paddingAngle={2}>
                {categoryData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="grid grid-cols-2 gap-1 mt-2">
            {categoryData.slice(0, 6).map((item, i) => (
              <div key={item.name} className="flex items-center gap-1.5 text-xs">
                <div className="w-2 h-2 rounded-full" style={{ backgroundColor: COLORS[i % COLORS.length] }} />
                <span className="text-gray-600 truncate">{item.name}</span>
                <span className="font-medium text-gray-900 ml-auto">{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Tickets */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-gray-900">Recent Tickets</h3>
            <button onClick={() => navigateTo('tickets')} className="text-xs text-blue-600 hover:text-blue-700 font-medium">View All</button>
          </div>
          <div className="space-y-3">
            {recentTickets.map(ticket => (
              <button
                key={ticket.id}
                onClick={() => navigateTo('ticket-detail', ticket.id)}
                className="w-full flex items-start gap-3 p-3 rounded-lg hover:bg-gray-50 transition-colors text-left"
              >
                <div className={`px-2 py-0.5 rounded text-xs font-medium border ${priorityColor(ticket.priority)}`}>
                  {ticket.priority}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">{ticket.subject}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{ticket.ticket_number} · {ticket.requester_name}</p>
                </div>
                <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${statusColor(ticket.status)}`}>
                  {ticket.status.replace('_', ' ')}
                </span>
              </button>
            ))}
          </div>
        </div>

        {/* Asset Status Overview */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-gray-900">Asset Inventory Status</h3>
            <button onClick={() => navigateTo('assets')} className="text-xs text-blue-600 hover:text-blue-700 font-medium">View All</button>
          </div>
          <div className="space-y-4">
            {statusData.map(item => (
              <div key={item.name}>
                <div className="flex items-center justify-between mb-1">
                  <span className="text-sm text-gray-700">{item.name}</span>
                  <span className="text-sm font-semibold text-gray-900">{item.count}</span>
                </div>
                <div className="w-full bg-gray-100 rounded-full h-2">
                  <div className="h-2 rounded-full transition-all" style={{ width: `${(item.count / totalAssets) * 100}%`, backgroundColor: item.color }} />
                </div>
              </div>
            ))}
          </div>

          {/* Inventory Alerts */}
          {lostStolen > 0 && (
            <div className="mt-5 p-3 bg-red-50 border border-red-200 rounded-lg">
              <div className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-red-600" />
                <p className="text-sm font-medium text-red-800">{lostStolen} asset(s) reported lost or stolen</p>
              </div>
              <p className="text-xs text-red-600 mt-1">Immediate action required. Review security incidents.</p>
            </div>
          )}

          {/* Category Counts */}
          <div className="mt-5">
            <h4 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">Inventory by Category</h4>
            <div className="grid grid-cols-2 gap-2">
              {Object.entries(assetCategories).map(([cat, count]) => {
                const available = assets.filter(a => a.category === cat && (a.status === 'available' || a.status === 'in_stock')).length;
                return (
                  <div key={cat} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                    <div>
                      <p className="text-xs font-medium text-gray-900">{cat}</p>
                      <p className="text-xs text-gray-500">{available} available</p>
                    </div>
                    <span className="text-lg font-bold text-gray-900">{count}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
