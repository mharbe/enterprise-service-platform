import React, { useState } from 'react';
import { useAppContext } from '@/contexts/AppContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import {
  Shield, Users, Building2, Plus, Edit, Trash2, Save, X, Check, Settings as SettingsIcon,
  Mail, Palette, Globe
} from 'lucide-react';

const permissionModules = ['assets', 'tickets', 'users', 'kb', 'integrations', 'settings', 'reports'];
const permissionActions: Record<string, string[]> = {
  assets: ['view', 'create', 'edit', 'delete'],
  tickets: ['view', 'create', 'edit', 'delete', 'assign'],
  users: ['view', 'create', 'edit', 'delete'],
  kb: ['view', 'create', 'edit', 'delete'],
  integrations: ['view', 'manage'],
  settings: ['view', 'manage'],
  reports: ['view'],
};

const SettingsView: React.FC = () => {
  const { roles, departments, createRole, updateRole, deleteRole, refreshData } = useAppContext();
  const [activeTab, setActiveTab] = useState<'roles' | 'departments' | 'general'>('roles');
  const [showCreateRole, setShowCreateRole] = useState(false);
  const [editingRole, setEditingRole] = useState<string | null>(null);
  const [newRole, setNewRole] = useState({ name: '', description: '', permissions: {} as Record<string, Record<string, boolean>> });
  const [showCreateDept, setShowCreateDept] = useState(false);
  const [newDept, setNewDept] = useState({ name: '', email: '', description: '', color: '#3B82F6' });

  const initPermissions = () => {
    const perms: Record<string, Record<string, boolean>> = {};
    permissionModules.forEach(mod => {
      perms[mod] = {};
      permissionActions[mod].forEach(action => { perms[mod][action] = false; });
    });
    return perms;
  };

  const togglePermission = (module: string, action: string) => {
    setNewRole(prev => ({
      ...prev,
      permissions: {
        ...prev.permissions,
        [module]: {
          ...(prev.permissions[module] || {}),
          [action]: !(prev.permissions[module]?.[action] || false),
        }
      }
    }));
  };

  const handleCreateRole = async () => {
    if (!newRole.name) return;
    await createRole(newRole as any);
    setShowCreateRole(false);
    setNewRole({ name: '', description: '', permissions: {} });
  };

  const handleDeleteRole = async (id: string) => {
    if (confirm('Are you sure you want to delete this role?')) {
      await deleteRole(id);
    }
  };

  const handleCreateDept = async () => {
    if (!newDept.name) return;
    const { error } = await supabase.from('departments').insert(newDept);
    if (error) { toast.error('Failed to create department'); return; }
    toast.success('Department created');
    setShowCreateDept(false);
    setNewDept({ name: '', email: '', description: '', color: '#3B82F6' });
    await refreshData();
  };

  const tabs = [
    { key: 'roles' as const, label: 'Roles & Permissions', icon: Shield },
    { key: 'departments' as const, label: 'Departments', icon: Building2 },
    { key: 'general' as const, label: 'General Settings', icon: SettingsIcon },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Settings</h1>
        <p className="text-sm text-gray-500 mt-1">Manage roles, departments, and platform configuration</p>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg w-fit">
        {tabs.map(tab => {
          const Icon = tab.icon;
          return (
            <button key={tab.key} onClick={() => setActiveTab(tab.key)}
              className={`flex items-center gap-2 px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                activeTab === tab.key ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600 hover:text-gray-900'
              }`}>
              <Icon className="w-4 h-4" /> {tab.label}
            </button>
          );
        })}
      </div>

      {/* Roles Tab */}
      {activeTab === 'roles' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Custom Roles</h2>
            <button onClick={() => { setShowCreateRole(true); setNewRole({ name: '', description: '', permissions: initPermissions() }); }}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center gap-2">
              <Plus className="w-4 h-4" /> Create Role
            </button>
          </div>

          <div className="space-y-4">
            {roles.map(role => (
              <div key={role.id} className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-sm font-semibold text-gray-900">{role.name}</h3>
                    <p className="text-xs text-gray-500">{role.description}</p>
                  </div>
                  <div className="flex gap-2">
                    <button onClick={() => { setEditingRole(role.id); setNewRole({ name: role.name, description: role.description, permissions: role.permissions || {} }); setShowCreateRole(true); }}
                      className="p-1.5 rounded-lg hover:bg-gray-100 text-gray-500"><Edit className="w-4 h-4" /></button>
                    <button onClick={() => handleDeleteRole(role.id)}
                      className="p-1.5 rounded-lg hover:bg-red-50 text-red-500"><Trash2 className="w-4 h-4" /></button>
                  </div>
                </div>
                {/* Permission Grid */}
                <div className="overflow-x-auto">
                  <table className="w-full text-xs">
                    <thead>
                      <tr className="border-b border-gray-100">
                        <th className="text-left py-1 pr-4 font-medium text-gray-500">Module</th>
                        {['view', 'create', 'edit', 'delete', 'assign', 'manage'].map(action => (
                          <th key={action} className="px-2 py-1 font-medium text-gray-500 text-center capitalize">{action}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {permissionModules.map(mod => (
                        <tr key={mod} className="border-b border-gray-50">
                          <td className="py-1.5 pr-4 font-medium text-gray-700 capitalize">{mod}</td>
                          {['view', 'create', 'edit', 'delete', 'assign', 'manage'].map(action => {
                            const hasAction = permissionActions[mod]?.includes(action);
                            const isEnabled = role.permissions?.[mod]?.[action];
                            return (
                              <td key={action} className="px-2 py-1.5 text-center">
                                {hasAction ? (
                                  isEnabled ? <Check className="w-3.5 h-3.5 text-green-600 mx-auto" /> : <X className="w-3.5 h-3.5 text-gray-300 mx-auto" />
                                ) : <span className="text-gray-200">-</span>}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Departments Tab */}
      {activeTab === 'departments' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-gray-900">Departments</h2>
            <button onClick={() => setShowCreateDept(true)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 flex items-center gap-2">
              <Plus className="w-4 h-4" /> Add Department
            </button>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {departments.map(dept => (
              <div key={dept.id} className="bg-white rounded-xl border border-gray-200 p-5">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: dept.color }} />
                  <h3 className="text-sm font-semibold text-gray-900">{dept.name}</h3>
                </div>
                <p className="text-xs text-gray-500 mb-2">{dept.description}</p>
                <div className="flex items-center gap-2 text-xs text-gray-500">
                  <Mail className="w-3 h-3" /> {dept.email}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* General Tab */}
      {activeTab === 'general' && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h3 className="text-sm font-semibold text-gray-900 mb-4">Platform Settings</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Organization Name</label>
                  <input type="text" defaultValue="Acme Corporation" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Support Email</label>
                  <input type="email" defaultValue="support@company.com" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Company Website</label>
                <input type="url" defaultValue="https://www.company.com" className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Email Submission Settings</label>
                <div className="p-4 bg-gray-50 rounded-lg space-y-3">
                  <p className="text-xs text-gray-600">Configure email addresses for ticket submission per department:</p>
                  {departments.map(d => (
                    <div key={d.id} className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full" style={{ backgroundColor: d.color }} />
                      <span className="text-sm text-gray-700 w-32">{d.name}</span>
                      <input type="email" defaultValue={d.email || ''} className="flex-1 px-3 py-1.5 border border-gray-300 rounded-lg text-sm" />
                    </div>
                  ))}
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-gray-900">AI Auto-Categorization</p>
                  <p className="text-xs text-gray-500">Automatically categorize and prioritize incoming tickets using AI</p>
                </div>
                <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-blue-600">
                  <span className="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-6" />
                </button>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="text-sm font-medium text-gray-900">AI KB Suggestions</p>
                  <p className="text-xs text-gray-500">Suggest KB article updates based on resolved tickets</p>
                </div>
                <button className="relative inline-flex h-6 w-11 items-center rounded-full bg-blue-600">
                  <span className="inline-block h-4 w-4 transform rounded-full bg-white transition translate-x-6" />
                </button>
              </div>
            </div>
            <button className="mt-4 px-6 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
              Save Settings
            </button>
          </div>
        </div>
      )}

      {/* Create Role Modal */}
      {showCreateRole && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => { setShowCreateRole(false); setEditingRole(null); }}>
          <div className="bg-white rounded-xl p-6 w-full max-w-2xl mx-4 max-h-[90vh] overflow-y-auto" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">{editingRole ? 'Edit Role' : 'Create Role'}</h3>
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Role Name *</label>
                  <input type="text" value={newRole.name} onChange={e => setNewRole({...newRole, name: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                  <input type="text" value={newRole.description} onChange={e => setNewRole({...newRole, description: e.target.value})}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Permissions</label>
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="bg-gray-50">
                        <th className="text-left px-4 py-2 font-medium text-gray-500">Module</th>
                        {['view', 'create', 'edit', 'delete', 'assign', 'manage'].map(a => (
                          <th key={a} className="px-3 py-2 font-medium text-gray-500 text-center capitalize text-xs">{a}</th>
                        ))}
                      </tr>
                    </thead>
                    <tbody>
                      {permissionModules.map(mod => (
                        <tr key={mod} className="border-t border-gray-100">
                          <td className="px-4 py-2 font-medium text-gray-700 capitalize">{mod}</td>
                          {['view', 'create', 'edit', 'delete', 'assign', 'manage'].map(action => {
                            const hasAction = permissionActions[mod]?.includes(action);
                            return (
                              <td key={action} className="px-3 py-2 text-center">
                                {hasAction ? (
                                  <input type="checkbox" checked={newRole.permissions?.[mod]?.[action] || false}
                                    onChange={() => togglePermission(mod, action)} className="rounded border-gray-300" />
                                ) : <span className="text-gray-200">-</span>}
                              </td>
                            );
                          })}
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => { setShowCreateRole(false); setEditingRole(null); }} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">Cancel</button>
              <button onClick={async () => {
                if (editingRole) { await updateRole(editingRole, newRole as any); setEditingRole(null); }
                else { await handleCreateRole(); }
                setShowCreateRole(false);
              }} className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">
                {editingRole ? 'Update Role' : 'Create Role'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Create Department Modal */}
      {showCreateDept && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50" onClick={() => setShowCreateDept(false)}>
          <div className="bg-white rounded-xl p-6 w-full max-w-md mx-4" onClick={e => e.stopPropagation()}>
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Add Department</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                <input type="text" value={newDept.name} onChange={e => setNewDept({...newDept, name: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Email</label>
                <input type="email" value={newDept.email} onChange={e => setNewDept({...newDept, email: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" placeholder="dept@company.com" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Description</label>
                <textarea value={newDept.description} onChange={e => setNewDept({...newDept, description: e.target.value})}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm" rows={2} />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Color</label>
                <input type="color" value={newDept.color} onChange={e => setNewDept({...newDept, color: e.target.value})}
                  className="w-full h-10 rounded-lg cursor-pointer" />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button onClick={() => setShowCreateDept(false)} className="flex-1 px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium hover:bg-gray-50">Cancel</button>
              <button onClick={handleCreateDept} className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700">Create</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default SettingsView;
